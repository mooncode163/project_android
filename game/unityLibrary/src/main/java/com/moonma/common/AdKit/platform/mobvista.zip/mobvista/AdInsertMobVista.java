package com.moonma.common;

import android.app.Activity;

import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.RelativeLayout;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.Toast;
import java.util.HashMap;


import com.moonma.common.IAdInsertBase;
import com.moonma.common.IAdInsertBaseListener; 
import com.moonma.common.AdConfigMobVista;


import com.mintegral.msdk.MIntegralConstans;
import com.mintegral.msdk.out.InterstitialListener;
import com.mintegral.msdk.out.MTGInterstitialHandler; 


 
public class AdInsertMobVista implements IAdInsertBase {

    // 自定义单一平台广告视图对象
    // private AdView adView;

    private static String TAG = "AdInsert";

    public boolean isUseActivity = false;// true
    boolean isAdInit;
    FrameLayout framelayout;
    Activity mainActivity;
    private boolean sIsShow;
    private int bannerOffsety;
    private float bannerAlhpha;
    String strAdAppId;
   
    private MTGInterstitialHandler mInterstitialHandler;

    private IAdInsertBaseListener adInsertBaseListener;

    public void init(Activity activity, FrameLayout layout) {
        mainActivity = activity;
        framelayout = layout;
        isAdInit = false;
    }

    public void setAd() {
        if(isAdInit==false)
        {
            isAdInit = true;
            initHandler();
        }
    }

    public void show() {

        mainActivity.runOnUiThread( new Runnable()
        {
            @Override
            public void run()
            {
                mInterstitialHandler.preload();

            }
        } );
    } 
 

    public void setListener(IAdInsertBaseListener listener) {
        adInsertBaseListener = listener;
    }



    private void initHandler() {
 
        String strAppKey = AdConfigMobVista.main().appKeyInsert;
        Log.v(TAG,"AdConfigMobVista:strAppKey="+strAppKey);
		HashMap<String, Object> hashMap = new HashMap<String, Object>();
		// 设置广告位ID
		hashMap.put(MIntegralConstans.PROPERTIES_UNIT_ID, strAppKey);//21312
		mInterstitialHandler = new MTGInterstitialHandler(mainActivity, hashMap);
		mInterstitialHandler.setInterstitialListener(new InterstitialListener() {
			@Override
			public void onInterstitialShowSuccess() {
                Log.e(TAG, "onInterstitialShowSuccess");
                if (adInsertBaseListener!=null){
                    adInsertBaseListener.adInsertWillShow();

                }
			}

			@Override
			public void onInterstitialShowFail(String errorMsg) {
				Log.e(TAG, "onInterstitialShowFail errorMsg:" + errorMsg);
			}

			@Override
			public void onInterstitialLoadSuccess() {
                Log.e(TAG, "onInterstitialLoadSuccess");
                
			if (mInterstitialHandler != null) {
				mInterstitialHandler.show();
			}
				//hideLoadding();
				//Toast.makeText(getApplicationContext(), "onInterstitialLoadSuccess", Toast.LENGTH_SHORT).show();
			}

			@Override
			public void onInterstitialLoadFail(String errorMsg) {
                Log.e(TAG, "onInterstitialLoadFail errorMsg:" + errorMsg);
                if (adInsertBaseListener!=null){
                    adInsertBaseListener.adInsertDidFail();

                }
			}

			@Override
			public void onInterstitialClosed() {
                Log.e(TAG, "onInterstitialClosed");
                if (adInsertBaseListener!=null){
                    adInsertBaseListener.adInsertDidClose();
                }
			}

			@Override
			public void onInterstitialAdClick() {
				Log.e(TAG, "onInterstitialAdClick");
			}
		});
	}
 
}

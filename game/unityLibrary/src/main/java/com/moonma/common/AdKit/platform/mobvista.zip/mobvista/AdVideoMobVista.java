package com.moonma.common;

import android.app.Activity;

import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.RelativeLayout;
import android.widget.Toast;

import org.json.JSONObject;

import com.moonma.common.IAdVideoBase;
import com.moonma.common.IAdVideoBaseListener; 
import com.moonma.common.AdConfigMobVista;




import android.app.Dialog;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.mintegral.msdk.MIntegralConstans;
import com.mintegral.msdk.out.MTGRewardVideoHandler;
import com.mintegral.msdk.out.RewardVideoListener;
import com.mintegral.msdk.videocommon.download.NetStateOnReceive; 


public class AdVideoMobVista implements IAdVideoBase {

    private static String TAG = "AdVideo";

    String strAdAppId;
    boolean isAdInit;
    // FrameLayout framelayout;
    Activity mainActivity;
    private boolean sIsShow;
    private int bannerOffsety;
    private float bannerAlhpha;

    int adType;
    private IAdVideoBaseListener adVideoBaseListener;



	private MTGRewardVideoHandler mMTGRewardVideoHandler; 
    private NetStateOnReceive mNetStateOnReceive;
    private String mRewardId = "1";//"12817";
    private String mUserId = "";//"123";
    boolean isAutoShow;
    boolean isLoading;

    public void init(Activity activity, FrameLayout layout) {
        mainActivity = activity;
        // framelayout = layout;
        isAdInit = false;
        isLoading = false;
    }

    public void setType(int type) {
        adType = type;
    }

    public void setAd() {
       
        if(isAdInit==false)
        {
            isAdInit = true;
            initHandler();
            loadAd(false);
        }
    }

    public void show() {

        mainActivity.runOnUiThread( new Runnable()
        {
            @Override
            public void run()
            { 
                if (mMTGRewardVideoHandler.isReady()) {
                    Log.d(TAG,"isReady false reload");
                    showAd();
                }else{
                    Log.d(TAG,"isReady false reload");
                    loadAd(true);
                }
            }
        } );
       
    }

    

    public void setListener(IAdVideoBaseListener listener) {
        adVideoBaseListener = listener;
    } 


    public void loadAd(boolean autoshow) {
        isAutoShow = autoshow;
        if(isLoading){
            Log.d(TAG,"ad is loading,waiting...");
            return;
        }
        mMTGRewardVideoHandler.load();
        isLoading = true;
    }
    public void showAd() { 
       // if (mMTGRewardVideoHandler.isReady())
        {
            mMTGRewardVideoHandler.show(mRewardId, mUserId);
        }
    }

	private void initHandler() {
		try {
			// Declare network status for downloading video
			if (mNetStateOnReceive == null) {
				mNetStateOnReceive = new NetStateOnReceive();
				IntentFilter filter = new IntentFilter();
				filter.addAction(ConnectivityManager.CONNECTIVITY_ACTION);
                mainActivity.registerReceiver(mNetStateOnReceive, filter);
			}
 
            String strAppKey = AdConfigMobVista.main().appKeyVideo;

			mMTGRewardVideoHandler = new MTGRewardVideoHandler(mainActivity, strAppKey);
			mMTGRewardVideoHandler.setRewardVideoListener(new RewardVideoListener() {
                public void onLoadSuccess(String unitId) {
                    Log.d(TAG, "onLoadSuccess:"+Thread.currentThread());

                }
				@Override
				public void onVideoLoadSuccess(String unitId) {
                    isLoading = false;
					Log.d(TAG, "onVideoLoadSuccess:"+Thread.currentThread()+" isAutoShow="+isAutoShow);
					//hideLoadding();
					//Toast.makeText(getApplicationContext(), "onVideoLoadSuccess()", Toast.LENGTH_SHORT).show();
                   if(isAutoShow){
                       showAd();
                   }
				}

				@Override
				public void onVideoLoadFail(String errorMsg) {
					Log.d(TAG, "onVideoLoadFail errorMsg:"+errorMsg);
                    isLoading = false;
					//hideLoadding();
                    //Toast.makeText(getApplicationContext(), errorMsg, Toast.LENGTH_SHORT).show();
                    if(adVideoBaseListener!=null){
                       adVideoBaseListener.adVideoDidFail();
                    }
				}

				@Override
				public void onShowFail(String errorMsg) {
					Log.d(TAG, "onShowFail=" + errorMsg);
					//Toast.makeText(getApplicationContext(), "errorMsg:" + errorMsg, Toast.LENGTH_SHORT).show();
				}

				@Override
				public void onAdShow() {
					Log.d(TAG, "onAdShow");
                    //Toast.makeText(getApplicationContext(), "onAdShow", Toast.LENGTH_SHORT).show();
                    if(adVideoBaseListener!=null){
                        adVideoBaseListener.adVideoDidStart();
                    }
				}

				@Override
				public void onAdClose(boolean isCompleteView, String RewardName, float RewardAmout) {
					Log.d(TAG, "onAdClose rewardinfo :" + "RewardName:" + RewardName + "RewardAmout:" + RewardAmout+" isCompleteView："+isCompleteView);
					if(isCompleteView){
						//Toast.makeText(getApplicationContext(),"onADClose:"+isCompleteView+",rName:"+RewardName +"，RewardAmout:"+RewardAmout,Toast.LENGTH_SHORT).show();
                        //showDialog(RewardName, RewardAmout);
                        if(adVideoBaseListener!=null){
                            adVideoBaseListener.adVideoDidFinish();
                        }
					}else{
						//Toast.makeText(getApplicationContext(),"onADClose:"+isCompleteView+",rName:"+RewardName +"，RewardAmout:"+RewardAmout,Toast.LENGTH_SHORT).show();
					}
				}

				@Override
				public void onVideoAdClicked(String unitId) {
					Log.e(TAG, "onVideoAdClicked");
					//Toast.makeText(getApplicationContext(), "onVideoAdClicked", Toast.LENGTH_SHORT).show();
				}

			});
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}

package com.moonma.common;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.ViewGroup;


import com.moonma.common.AdConfigBase;

import com.kyview.InitConfiguration;
import com.kyview.InitConfiguration.BannerSwitcher;
import com.kyview.InitConfiguration.RunMode;
import com.kyview.InitConfiguration.UpdateMode;
import com.kyview.interfaces.AdViewSpreadListener;
import com.kyview.manager.AdViewBannerManager;
import com.kyview.manager.AdViewInstlManager;
import com.kyview.manager.AdViewNativeManager;
import com.kyview.manager.AdViewSpreadManager;
import com.kyview.manager.AdViewVideoManager;

/**
 * Created by jaykie on 16/5/24.
 */
public class AdConfigAdView extends AdConfigBase {
	private static AdConfigAdView _mian = null;

	public static AdConfigAdView main() {
		if (_mian == null) {
			_mian = new AdConfigAdView();
		}
		return _mian;
	}

	public static InitConfiguration initConfiguration = null;

	public void onInit(final Activity ac, String appId) {
		if (initConfiguration != null) {
			return;
		}
		// String key_adview_demo = "SDK20161629040641z7snyxkrbndasty";
		String keySet[] = new String[] { appId };

		// 获取后台配置
		initConfiguration = new InitConfiguration.Builder(ac).setUpdateMode(UpdateMode.EVERYTIME)
				.setBannerCloseble(BannerSwitcher.CANCLOSED).setRunMode(RunMode.TEST).build();
		// 横幅 配置
		AdViewBannerManager.getInstance(ac).init(initConfiguration, keySet);
		// 插屏 配置
		AdViewInstlManager.getInstance(ac).init(initConfiguration, keySet);
		// 原生 配置
		// AdViewNativeManager.getInstance(this).init(initConfiguration,
		// MainActivity.keySet);
		// 开屏 配置
		// AdViewSpreadManager.getInstance(this).init(initConfiguration,
		// MainActivity.keySet);
		// 视频 配置
		AdViewVideoManager.getInstance(ac).init(initConfiguration, keySet);
		// 设置倒计时
		// AdViewSpreadManager.getInstance(this).setSpreadNotifyType(AdViewSpreadManager.NOTIFY_COUNTER_NUM);
		// // 设置开屏下方LOGO，必须调用该方法
		// AdViewSpreadManager.getInstance(this).setSpreadLogo(R.drawable.adview_logo);
		// // 设置开屏背景颜色，可不设置
		// AdViewSpreadManager.getInstance(this).setSpreadBackgroudColor(
		// Color.WHITE);

		// // 请求开屏广告(null:其他平台传null，广点通可以为null使用广点通默认布局，也可以传自定义跳过布局 (RelativeLayout)
		// findViewById(R.id.skip_view))
		// AdViewSpreadManager.getInstance(this).request(this, MainActivity.key1,this,
		// (RelativeLayout) findViewById(R.id.spreadlayout),null);

	}

}

package com.hdvideoplayer.player.phone.player;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.PixelFormat;
import android.media.AudioManager;
import android.os.Bundle;
import android.os.Handler;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Gravity;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.widget.FrameLayout;
import com.hdvideoplayer.player.phone.data.IVideo;

import com.hdvideoplayer.player.phone.util.BitmapUtil;
import com.hdvideoplayer.player.phone.util.SDCardUtil;
import com.hdvideoplayer.player.phone.util.funClass;
import org.videolan.libvlc.LibVLC;
import org.videolan.libvlc.media.MediaPlayer;
import org.videolan.libvlc.media.MediaPlayer.OnBufferingUpdateListener;
import org.videolan.libvlc.media.MediaPlayer.OnCompletionListener;
import org.videolan.libvlc.media.MediaPlayer.OnErrorListener;
import org.videolan.libvlc.media.MediaPlayer.OnInfoListener;
import org.videolan.libvlc.media.MediaPlayer.OnPreparedListener;
import org.videolan.libvlc.media.MediaPlayer.OnVideoSizeChangedListener;
import org.videolan.libvlc.media.MediaPlayer.OnHardwareAccelerationListener;

import org.videolan.libvlc.media.MediaPlayer.TrackInfo;
import org.videolan.libvlc.util.VLCUtil;


import java.lang.reflect.Method;
import java.nio.ByteBuffer;

/**
 * Created by jaykie on 16/4/18.
 */


public class VLCPlayer implements IPlayer,OnBufferingUpdateListener,OnCompletionListener,OnInfoListener,OnErrorListener,OnPreparedListener,OnVideoSizeChangedListener,OnHardwareAccelerationListener {

    private static final String TAG = "VitamioPlayer";

    private IPlayListener listener;
    private IVideo video;
    private boolean isPlaying; // 只要打开了视频(包括暂停),知道关闭视频,就算正在播放
    private int pauseTime;

    //vitamio player
    private Activity mActivity;
    private Context mContext;
    private int volPercent;
    private int mVideoWidth;
    private int mVideoHeight;
    private int mVideoX;
    private int mVideoY;
    //private MediaPlayer mMediaPlayer;
    private static MediaPlayer mMediaPlayer = null;
    private SurfaceView mPreview;
    private SurfaceHolder holder;
    private String path;
    private Bundle extras;
    private static final String MEDIA = "media";
    private static final int LOCAL_AUDIO = 1;
    private static final int STREAM_AUDIO = 2;
    private static final int RESOURCES_AUDIO = 3;
    private static final int LOCAL_VIDEO = 4;
    private static final int STREAM_VIDEO = 5;
    private boolean mIsVideoSizeKnown = false;
    private boolean mIsVideoReadyToBePlayed = false;
    public boolean mIsUseHWDecode;
    private int mVideoChroma =0;// MediaPlayer.VIDEOCHROMA_RGBA;
    int timeStartTo;


    public void setActivity(Activity ac)
    {
        mActivity = ac;
    }

    @Override
    public void setIsUseHWDecode(boolean isHW)
    {
        mIsUseHWDecode = isHW;
    }
    @Override
    public void setContext(Context ctx)
    {
        // TODO Auto-generated method stub
        //vitamio
       // mIsUseHWDecode = true;


        mediaplayer_setcontext(ctx);
    }



    @Override
    public void setPlayerListener(IPlayListener listener) {
        // TODO Auto-generated method stub
        this.listener = listener;
    }








    @Override
    public void initPlayerListeners() {
        // TODO Auto-generated method stub
        {

            try {

                if(mMediaPlayer==null) {
                    // Create a new media player and set the listeners
                    //mMediaPlayer = new MediaPlayer(mContext, mIsUseHWDecode);
                }
                //mMediaPlayer.setDisplay(holder);
               // mMediaPlayer.prepareAsync();

                //  setVolumeControlStream(AudioManager.STREAM_MUSIC);


            } catch (Exception e) {
                Log.e(TAG, "error: " + e.getMessage(), e);
            }
        }
    }

	/*@Override
	public void prepareDisplay(SurfaceHolder surfaceHolder, int width,
			int height) throws IllegalStateException {
		// TODO Auto-generated method stub

	}*/

    @Override
    public void start() {
        // TODO Auto-generated method stub
        if(mMediaPlayer!=null) {
            mMediaPlayer.start();
            // Cocos2dxActivity.cocos2dxActivity.mediaPlayerUpdatePlayStatus();
        }

        isPlaying = true;
        listener.onStarted();
//        mActivity.runOnUiThread(new Runnable() {
//            @Override
//            public void run() {
//
//                listener.onStarted();
//            }
//        });
    }

    @Override
    public void startTo(int seekDuration) {
        // TODO Auto-generated method stub
        timeStartTo =  seekDuration * 1000;
                                //@moon 200以下会出问题，卡住 300偶尔会卡住,华为手机直接闪退
//                                long delay = 500;//ms 2000 1000 500
//                        new Handler().postDelayed(new Runnable(){
//                            public void run() {
//                                //execute the task
//                                mMediaPlayer.seekTo(timeStartTo);
//                            }
//                        }, delay);

    //@moon mtk芯片等手机直接seek
     mMediaPlayer.seekTo(timeStartTo);




//               mActivity.runOnUiThread(new Runnable() {
//            @Override
//            public void run() {
//
//                mMediaPlayer.seekTo(timeStartTo);
//            }
//        });
//        try {
//            if (null != mMediaPlayer) {
//                mMediaPlayer.seekTo(seekDuration * 1000);
//               // mMediaPlayer.start();
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//            listener.onError(0);
//            return;
//        }

        isPlaying = true;
        listener.onStarted();
//        mActivity.runOnUiThread(new Runnable() {
//            @Override
//            public void run() {
//
//                listener.onStarted();
//            }
//        });
    }

    @Override
    public void pause() {
        // TODO Auto-generated method stub
        if(mMediaPlayer!=null){

            mMediaPlayer.pause();
            //Cocos2dxActivity.cocos2dxActivity.mediaPlayerUpdatePlayStatus();
        }
        listener.onPaused();
//        mActivity.runOnUiThread(new Runnable() {
//            @Override
//            public void run() {
//
//                listener.onPaused();
//            }
//        });
    }

    @Override
    public void resume() {
        // TODO Auto-generated method stub
        if (null != mMediaPlayer) {
            if (pauseTime > 0) {
                // mediaPlayer.seekTo(pauseTime);
                pauseTime = 0;
            }
            mMediaPlayer.start(); // 可以从暂停的时候直接播放,而不是从头播放
        }

        listener.onResumed();
//        mActivity.runOnUiThread(new Runnable() {
//            @Override
//            public void run() {
//
//                listener.onResumed();
//            }
//        });
    }

    @Override
    public void seekTo(int seekDuration) {
        // TODO Auto-generated method stub

        int p = seekDuration * 1000;
        if (pauseTime > 0)
            pauseTime = (int)p;


       int total_ms = mMediaPlayer.getDuration();
//p = 35000;

        if (null != mMediaPlayer) {
            mMediaPlayer.seekTo(p);
        }
    }

    @Override
    public void stop() {
        // TODO Auto-generated method stub
        if (null != mMediaPlayer) {
            mMediaPlayer.stop();
        }

        isPlaying = false;
        listener.onStopped();
//        mActivity.runOnUiThread(new Runnable() {
//            @Override
//            public void run() {
//
//                listener.onStopped();
//            }
//        });
    }

    @Override
    public long getDuration() {
        // TODO Auto-generated method stub
         long ms = 0;
            if(mMediaPlayer!=null)
            {
                ms = mMediaPlayer.getDuration();
            }


            return ms/1000;

    }

    @Override
    public long getPlayingDuration() {
        // TODO Auto-generated method stub

            if (pauseTime > 0)
                return pauseTime / 1000;

            if (mMediaPlayer == null)
                return 0;

            return mMediaPlayer.getCurrentPosition() / 1000;

    }

    //
    @Override
    public long getCurDuration() {
        long ms = 0;
        if(mMediaPlayer!=null)
        {
            ms = mMediaPlayer.getCurrentTime();
        }

        return ms;
    }

    @Override
    public boolean isPlaying() {
        // TODO Auto-generated method stub
        boolean ret = false;
        if(mMediaPlayer!=null){

            ret = mMediaPlayer.isPlaying();
        }
        return ret;
    }

    @Override
    public void release() {
        // TODO Auto-generated method stub

            isPlaying = false;
            if (mMediaPlayer == null)
                return;

       // mMediaPlayer.setAudioStreamType(AudioManager.STREAM_SYSTEM);
        //mMediaPlayer.setDisplay(null);
        //mMediaPlayer.pause();
       // mMediaPlayer.stop();
//        mActivity.runOnUiThread(new Runnable() {
//            @Override
//            public void run() {
//
//
//            }
//        });
        mMediaPlayer.stopNotrelease();

//        mMediaPlayer.release();
//        mMediaPlayer = null;
        holder = null;
        doCleanUp();

    }

    @Override
    public void setDataSource(IVideo video) {
        // TODO Auto-generated method stub
        this.video = video;

        try {
            if (mMediaPlayer == null) {

                mMediaPlayer = new MediaPlayer();
            }
            ///mnt/sdcard/tencent/MicroMsg/755884a7ec79372a2382ddee6c19f418/video/194318150416f52d141844717.mp4
           // Log.v(TAG, this.video.getPath());
            if(mIsUseHWDecode){
                mMediaPlayer.setDecodeMode(mMediaPlayer.HW_ACCELERATION_AUTOMATIC);
            }else{
                mMediaPlayer.setDecodeMode(mMediaPlayer.HW_ACCELERATION_DISABLED);

            }
            long last_time_ms = 0;
            mMediaPlayer.setDataSource(this.video.getPath(),last_time_ms);
            //mMediaPlayer.setDisplay(holder);
          //  mMediaPlayer.prepareAsync();
        } catch (Exception e) {
            // TODO: handle exception
            e.printStackTrace();
            listener.onError(0);
        }
    }

    @Override
    public int getVideoWidth() {
        // TODO Auto-generated method stub
        int nVideoW = 0;
        if (null != mMediaPlayer) {
            nVideoW = mMediaPlayer.getVideoWidth();
        }
        return nVideoW;
    }

    @Override
    public int getVideoHeight() {
        // TODO Auto-generated method stub
        int nVideoH = 0;
        if (null != mMediaPlayer) {
            nVideoH = mMediaPlayer.getVideoHeight();
        }
        return nVideoH;
    }


    public int getVideoDispWidth()
    {
        int ret =0;
        if (mMediaPlayer!=null)
        {
            ret = mMediaPlayer.getVideoDispWidth();
        }
        return ret;
    }

    public int getVideoDispHeight()
    {
        int ret =0;
        if (mMediaPlayer!=null)
        {
            ret = mMediaPlayer.getVideoDispHeight();
        }
        return ret;
    }

    public void setDisplay(SurfaceView surfaceView)
    {

        if (mMediaPlayer == null)
            throw new IllegalStateException("Pls prepare engine first!");

        try {
            if (null != surfaceView) {
               // surfaceView.getHolder().setType(
                //        SurfaceHolder.SURFACE_TYPE_PUSH_BUFFERS);
                SurfaceHolder h = surfaceView.getHolder();
           //
          //  holder.addCallback(this);
            //holder.setFormat(PixelFormat.RGBA_8888);//RGBA_8888
            //extras = getIntent().getExtras();
            if(holder == null) {
                holder = h;
               // h.setType(
                      //  SurfaceHolder.SURFACE_TYPE_PUSH_BUFFERS);
               // mMediaPlayer.setDisplay(null);
                mMediaPlayer.setSurfaceView(surfaceView);
                //mMediaPlayer.setDisplay(h);
               // setVideoChroma(MediaPlayer.VIDEOCHROMA_RGB565 );//VIDEOCHROMA_RGB565
               // mMediaPlayer.setVideoChroma(mVideoChroma == MediaPlayer.VIDEOCHROMA_RGB565 ? MediaPlayer.VIDEOCHROMA_RGB565 : MediaPlayer.VIDEOCHROMA_RGBA);
            }
               // mMediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
            } else {
                mMediaPlayer.setDisplay(null);
            }
        } catch (Exception e) {
            // TODO: handle exception
            listener.onError(0);
        }
    }


    @Override
    public void reset() {
        // TODO Auto-generated method stub
        if (null != mMediaPlayer) {
            mMediaPlayer.reset();
        }
    }

    @Override
    public void prepareAsync() {
        // TODO Auto-generated method stub
        try {
            if (null != mMediaPlayer) {


                mMediaPlayer.setOnBufferingUpdateListener(this);
                mMediaPlayer.setOnCompletionListener(this);
                mMediaPlayer.setOnPreparedListener(this);
                mMediaPlayer.setOnVideoSizeChangedListener(this);
                mMediaPlayer.setOnInfoListener(this);
                mMediaPlayer.setOnErrorListener(this);
                mMediaPlayer.setOnHardwareAccelerationListener(this);

                mMediaPlayer.prepareAsync();
            }
        } catch (Exception e) {
            e.printStackTrace();
            listener.onError(0);
        }
    }

    @Override
    public Bitmap snap(String filePath, int ms)
            throws UnsupportedOperationException {
        // TODO Auto-generated method stub
        return null;
    }

    public void Enable3d(boolean s3d)
    {
    }

    public boolean S3DSupported()
    {
        return false;
    }
    public void SetS3dMode(boolean s3d)
    {

    }

    public Bitmap CaptureCurImage()
    {
        Bitmap bitmap = null;

        if (mMediaPlayer!=null) {
            return null;
        }

        if (null == mMediaPlayer) {
            return null;
        }


        if (SDCardUtil.isSDCardExist()==false)
        {
            return null;
        }

       String strDir = SDCardUtil.getSDCardPath();
       String path = strDir+ "/HDplayer/videoSnapShot_tmp.png";
       int width = mMediaPlayer.getVideoWidth();
       int height = mMediaPlayer.getVideoHeight();
        //second
        float playtime_second = mMediaPlayer.getCurrentPosition()/1000;


        //ok
        // Get the thumbnail.
        bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
        //byte[] b = VLCUtil.getVideoSnapShotData(mMediaPlayer.getMedia(),width, height);
        byte[] b = VLCUtil.getVideoSnapShotDataAtTime(mMediaPlayer.getMedia(),width, height,playtime_second);//getThumbnail

        if (b == null) // We were not able to create a thumbnail for this item.
            return null;
        bitmap.copyPixelsFromBuffer(ByteBuffer.wrap(b));
        bitmap =BitmapUtil.cropBorders(bitmap, width, height);


//
//width = 160;
//height = 90;
        //error
//       boolean ret = mMediaPlayer.getVideoSnapShot(path,width,height);
//
//        if (ret == true)
//        {
//            bitmap = funClass.LoadBitamp(path);
//
//        }





       // Bitmap bitmap = mMediaPlayer.getCurrentFrame();
        return bitmap;

//
//
//        long ntime = mMediaPlayer.getCurrentPosition();
//
//
//
//        // 使用反射机制,2.2也可以使用
//        String className = "android.media.MediaMetadataRetriever";
//        Object objectMediaMetadataRetriever = null;
//        Method release = null;
//        try {
//            objectMediaMetadataRetriever = Class.forName(className)
//                    .newInstance();
//
//            // 获取方法:setDataSource(String);
//            Method setDataSourceMethod = Class.forName(className).getMethod(
//                    "setDataSource", String.class);
//            String strPath = video.getPath();
//            setDataSourceMethod.invoke(objectMediaMetadataRetriever, strPath);
//
//            // 获取方法getFrameAtTime(long,int);
//            Method getFrameAtTimeMethod = Class.forName(className).getMethod(
//                    "getFrameAtTime", long.class, int.class);
//            bitmap = (Bitmap) getFrameAtTimeMethod.invoke(
//                    objectMediaMetadataRetriever, ntime * 1000, 0x03);
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            try {
//                if (null != objectMediaMetadataRetriever) {
//                    // 获取方法release();
//                    release = Class.forName(className).getMethod("release");
//                }
//
//                if (release != null) {
//                    release.invoke(objectMediaMetadataRetriever);
//                    objectMediaMetadataRetriever = null;
//                }
//            } catch (Exception e) {
//                e.printStackTrace();
//            }
//
//            // funClass.saveBitmap("/mnt/sdcard/", "testtest", bitmap);
//        }
//
//
//
//        return bitmap;
    }


    public void setVideoChroma(int chroma) {
       // holder.setFormat(chroma == MediaPlayer.VIDEOCHROMA_RGB565 ? PixelFormat.RGB_565 : PixelFormat.RGBA_8888); // PixelFormat.RGB_565
        mVideoChroma = chroma;
    }

    public void mediaplayer_setcontext(Context ctx)
    {
        mContext = ctx;

    }

    public  void mediaplayer_setVideoDisplay(int x,int y,int w,int h,boolean isauto)
    {
        // Cocos2dxActivity.cocos2dxActivity.mVV.setDecodeMode();

        mVideoWidth = w;
        mVideoHeight = h;
        mVideoX = x;
        mVideoY = y;

        {
//            DisplayMetrics dm = new DisplayMetrics();
//            getWindowManager().getDefaultDisplay().getMetrics(dm);
//            int height = dm.heightPixels;
//            int width = dm.widthPixels;



            FrameLayout.LayoutParams cameraFL = new FrameLayout.LayoutParams(w, h,Gravity.TOP); // set size
            cameraFL.setMargins(x, y, 0, 0);  // set position
            mPreview.setLayoutParams(cameraFL);
            holder.setFixedSize(mVideoWidth, mVideoHeight);
        }

        //
    }






    private void startVideoPlayback() {
        Log.v(TAG, "startVideoPlayback");
       // holder.setFixedSize(mVideoWidth, mVideoHeight);
        //mMediaPlayer.start();
        //Cocos2dxActivity.cocos2dxActivity.mediaPlayerUpdatePlayStatus();
        // mPreview.setVisibility(View.VISIBLE);
        //Cocos2dxActivity.cocos2dxActivity.mediaplayer_showVideoView(true);

    }



    public void onHardwareAccelerationFailed()
    {
        Log.e(TAG, "onHardwareAccelerationFailed");

    }
    public void onBufferingUpdate(MediaPlayer arg0, int percent) {
        // Log.d(TAG, "onBufferingUpdate percent:" + percent);

    }


    public void onCompletion(MediaPlayer arg0)
    {
        Log.d(TAG, "onCompletion called");
        isPlaying = false;
        listener.onFinished();
//        mActivity.runOnUiThread(new Runnable() {
//            @Override
//            public void run() {
//
//                listener.onFinished();
//            }
//        });
    }

    public void onVideoSizeChanged(MediaPlayer mp, int width, int height) {
        Log.v(TAG, "onVideoSizeChanged called");
        if (width == 0 || height == 0) {
            Log.e(TAG, "invalid video width(" + width + ") or height(" + height + ")");
            return;
        }
        mIsVideoSizeKnown = true;
        mVideoWidth = width;
        mVideoHeight = height;
        if (mIsVideoReadyToBePlayed && mIsVideoSizeKnown) {
           // startVideoPlayback();
        }

        try {
            if (null != listener) {
                listener.onVideoSizeChanged();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void onPrepared(MediaPlayer mediaplayer) {
        Log.d(TAG, "onPrepared called");
        mIsVideoReadyToBePlayed = true;
       // if (mIsVideoReadyToBePlayed && mIsVideoSizeKnown)
        {
            //startVideoPlayback();

            isPlaying = true; // 缓冲完成,开始播放

            listener.onPrepared();
//            mActivity.runOnUiThread(new Runnable() {
//                @Override
//                public void run() {
//
//                    listener.onPrepared();
//                }
//            });
           // Cocos2dxActivity.cocos2dxActivity.mediaPlayerPrepareToPlay();


        }
    }


    /**
     * Called to indicate an error.
     *
     * @param mp    the MediaPlayer the error pertains to
     * @param what  the type of error that has occurred:
     *              <ul>
     *              <li>{@link #MEDIA_ERROR_UNKNOWN}
     *              <li>
     *              {@link #MEDIA_ERROR_NOT_VALID_FOR_PROGRESSIVE_PLAYBACK}
     *              </ul>
     * @param extra an extra code, specific to the error. Typically implementation
     *              dependant.
     * @return True if the method handled the error, false if it didn't.
     *         Returning false, or not having an OnErrorListener at all, will
     *         cause the OnCompletionListener to be called.
     */

    public boolean onError(MediaPlayer mp, int what, int extra)
    {
        switch (what)
        {
            case MediaPlayer.MEDIA_ERROR_UNKNOWN:
                isPlaying = false;
                listener.onError(what);
                break;


        }


        return true;
    }
    public boolean onInfo(MediaPlayer mp, int what, int extra)
    {

        return true;
    }
    private void doCleanUp() {
        mVideoWidth = 0;
        mVideoHeight = 0;
        mIsVideoReadyToBePlayed = false;
        mIsVideoSizeKnown = false;
    }


}

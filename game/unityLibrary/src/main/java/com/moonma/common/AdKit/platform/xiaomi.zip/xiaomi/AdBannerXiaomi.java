package com.moonma.common;

import android.app.Activity;

import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.RelativeLayout;


import com.moonma.common.AdSplashXiaomi;
import com.moonma.common.IAdBannerBase;
import com.moonma.common.IAdBannerBaseListener;
import com.moonma.common.AdConfigXiaomi;

import com.miui.zeus.mimo.sdk.ad.AdWorkerFactory;
import com.miui.zeus.mimo.sdk.ad.IAdWorker;
import com.miui.zeus.mimo.sdk.listener.MimoAdListener;
import com.xiaomi.ad.common.pojo.AdType;

import org.json.JSONObject;



public class AdBannerXiaomi implements IAdBannerBase {

    // 自定义单一平台广告视图对象
    //private AdView adView;
    private static final String BANNER_POS_ID = "802e356f1726f9ff39c69308bfd6f06a";

    private static String TAG = "AdXiaomi";

    FrameLayout framelayout;
    Activity mainActivity;
    private boolean sIsShow;
    private int bannerOffsety;
    private float bannerAlhpha;

    //  AdView adView;
    FrameLayout framelayoutAd;
    private IAdBannerBaseListener adBannerBaseListener;
    boolean isAdInit;

    int banner_height = 136;


    IAdWorker mBannerAd;
    Handler mHandlerAd;
    long adTimeOut = 4000;//ms
    boolean isLoadAdFinish = false;

    public void init(Activity activity, FrameLayout layout) {
        mainActivity = activity;
        framelayout = layout;
        isAdInit = false;
        sIsShow = false;

    }

    public void setAd() {

        String strAppId = AdConfigXiaomi.main().appId;
        String strAppKey = AdConfigXiaomi.main().appKeyBanner;

        if (isAdInit == false) {
            isAdInit = true;


            Log.i(TAG, "banner id=" + strAppId + " key=" + strAppKey);


            //将adView添加到父控件中(注：该父控件不一定为您的根控件，只要该控件能通过addView能添加广告视图即可)
            RelativeLayout.LayoutParams rllp = new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.FILL_PARENT, RelativeLayout.LayoutParams.WRAP_CONTENT);
            rllp.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM);
            //rllp.addRule(RelativeLayout.CENTER_HORIZONTAL);


            // FrameLayout
            ViewGroup.LayoutParams framelayout_params =
                    new ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                            ViewGroup.LayoutParams.WRAP_CONTENT);
            framelayoutAd = new FrameLayout(mainActivity);
            framelayoutAd.setLayoutParams(framelayout_params);

            //framelayoutAd.addView(mBannerAd);
            framelayout.addView(framelayoutAd, rllp);


            // adView.setVisibility(View.GONE);
            framelayoutAd.setVisibility(View.GONE);


            try{
                mBannerAd = AdWorkerFactory.getAdWorker(mainActivity, framelayoutAd, new MimoAdListener() {
                    @Override
                    public void onAdPresent() {
                        Log.e(TAG, "onAdPresent");
                        isLoadAdFinish = true;
                        Log.d(TAG, "AdBannerXiaomi:ad has been showed!");
                        if (adBannerBaseListener != null) {
                            int w, h;
                            w = framelayoutAd.getWidth();

                            h = banner_height;
                            adBannerBaseListener.onReceiveAd(w, h);

                            setOffsetY(bannerOffsety);
                        }
                    }

                    @Override
                    public void onAdClick() {
                        Log.e(TAG, "onAdClick");
                    }

                    @Override
                    public void onAdDismissed() {
                        Log.d(TAG, "AdBannerXiaomi:onAdDismissed");
                    }

                    @Override
                    public void onAdFailed(String s) {
                        isLoadAdFinish = true;
                        Log.d(TAG, "AdBannerXiaomi:onAdFailed "+s);
                        if (adBannerBaseListener != null) {
                            adBannerBaseListener.onLoadAdFail();
                        }
                    }

                    @Override
                    public void onAdLoaded() {
                        isLoadAdFinish = true;
                        Log.d(TAG, "AdBannerXiaomi:onAdLoaded");
                    }
                }, AdType.AD_BANNER);

                mBannerAd.loadAndShow(strAppKey);
                setTimeOutAd();
            }catch (Exception e) {
                e.printStackTrace();
            }
        }



        if(strAppKey.equals("0")){
            if (adBannerBaseListener!=null){
                adBannerBaseListener.onLoadAdFail();
            }
        }

    }
    void setTimeOutAd()
    {
        isLoadAdFinish = false;
        mHandlerAd = new Handler();
        Runnable r = new Runnable() {

            @Override
            public void run() {
                //do something
                onTimeOutAd();
                //每隔1s循环执行run方法
                // mHandler.postDelayed(this, 1000);
            }
        };
        mHandlerAd.postDelayed(r, adTimeOut);//延时毫秒
    }
    void onTimeOutAd()
    {
        if(!isLoadAdFinish)
        {
            //超时当作失败处理
            if (adBannerBaseListener != null) {
                adBannerBaseListener.onLoadAdFail();
            }
        }

    }


    public void setAlpha(float alpha) {

        bannerAlhpha = alpha;
        if (mainActivity == null) {
            return;
        }
        mainActivity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (bannerAlhpha < 1.0) {
                    //  bannerAlhpha =0;
                }
                framelayoutAd.setAlpha(bannerAlhpha);


            }
        });

    }

    public void show(boolean isShow) {
        sIsShow = isShow;

        if (mainActivity == null) {
            return;
        }


        mainActivity.runOnUiThread(new Runnable() {
            @Override
            public void run() {

                if (mBannerAd == null) {
                    return;
                }
                if (sIsShow) {


                    //bv.loadAD();
                    framelayoutAd.setVisibility(View.VISIBLE);

                } else {

                    framelayoutAd.setVisibility(View.GONE);
                }
            }
        });


    }


    public void layoutSubView(int w, int h) {
        setOffsetY(bannerOffsety);

    }

    public void setOffsetY(int y) {

        bannerOffsety = y;
//
//
        if ((mBannerAd == null) || (framelayout == null) || (mainActivity == null)) {
            return;
        }
        mainActivity.runOnUiThread(new Runnable() {
            @Override
            public void run() {


                ViewGroup.LayoutParams layout = framelayoutAd.getLayoutParams();
                int screen_w = framelayout.getWidth();
                int w = framelayoutAd.getWidth();

                int screen_h = framelayout.getHeight();
                int h = banner_height;


                int x = (screen_w - w) / 2;
                int y = screen_h - h - bannerOffsety-ScreenUtil.getBottomNavigationBarHeight();

                if (h == 0) {
                    //显示到屏幕外
                    // y =  screen_h;

                }
                //adView.setX(x);
                // adView.setY(y);

                framelayoutAd.setX(x);
                framelayoutAd.setY(y);


                // FrameLayout.LayoutParams cameraFL = new FrameLayout.LayoutParams(w, h,Gravity.TOP); // set size
                // cameraFL.setMargins(x, y, 0, 0);  // set position
                //adsMogoLayoutCode.setLayoutParams(cameraFL);


                framelayoutAd.bringToFront();
            }
        });

    }

    public void setListener(IAdBannerBaseListener listener) {
        adBannerBaseListener = listener;
    }


}

package com.moonma.common;

import android.app.Activity;

import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.RelativeLayout;
import org.json.JSONObject;

import com.moonma.common.IAdInsertBase;
import com.moonma.common.IAdInsertBaseListener;
import com.moonma.common.AdConfigXiaomi;

import com.miui.zeus.mimo.sdk.ad.AdWorkerFactory;
import com.miui.zeus.mimo.sdk.ad.IAdWorker;
import com.miui.zeus.mimo.sdk.listener.MimoAdListener;
import com.xiaomi.ad.common.pojo.AdType;


public class AdInsertXiaomi implements IAdInsertBase {

	// 自定义单一平台广告视图对象
	//private AdView adView;
    private static final String POSITION_ID = "67b05e7cc9533510d4b8d9d4d78d0ae9";
    String mStrAppKey;

    private static String TAG = "AdXiaomi";

    public boolean isUseActivity = false;//true
    boolean isAdInit;
    FrameLayout framelayout;
    Activity mainActivity;
    private   boolean sIsShow;
    private   int bannerOffsety;
    private   float bannerAlhpha;

    private IAdWorker mAdWorker;

    private IAdInsertBaseListener adInsertBaseListener;

    public   void init(  Activity activity,FrameLayout layout)
    {
        mainActivity = activity;
        framelayout = layout;
        isAdInit = false;
    }


     public void setAd()
    {

        if(isAdInit==false)
        {
            isAdInit = true;
            String strAppId = AdConfigXiaomi.main().appId;
            String strAppKey = AdConfigXiaomi.main().appKeyInsert;
            Log.i(TAG, "insert id="+strAppId+ " key="+strAppKey);
            mStrAppKey = strAppKey;




            try {
                mAdWorker = AdWorkerFactory.getAdWorker(mainActivity, framelayout, new MimoAdListener() {
                    @Override
                    public void onAdPresent() {
                        Log.d(TAG, "AdInsertXiaomi:onAdLoaded");
                        if (adInsertBaseListener!=null){
                            adInsertBaseListener.adInsertWillShow();

                        }
                    }

                    @Override
                    public void onAdClick() { 
                        Log.d(TAG, "AdInsertXiaomi:onAdClick");
                    }

                    @Override
                    public void onAdDismissed() {
                         Log.d(TAG, "AdInsertXiaomi:onAdDismissed");
                        if (adInsertBaseListener!=null){
                            adInsertBaseListener.adInsertDidClose();

                        }
                    }

                    @Override
                    public void onAdFailed(String s) {
                        Log.d(TAG, "AdInsertXiaomi:onAdFailed "+s);
                        if (adInsertBaseListener!=null){
                            adInsertBaseListener.adInsertDidFail();
                        }
                    }

                    @Override
                    public void onAdLoaded() {
                         Log.d(TAG, "AdInsertXiaomi:onAdLoaded");

                        try {
                            if (mAdWorker.isReady()) {
                                mAdWorker.show();
                            }
                        } catch (Exception e) {
                        }
                    }
                }, AdType.AD_INTERSTITIAL);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

    }
    
    public void show( )
    {


        mainActivity.runOnUiThread( new Runnable()
        {
            @Override
            public void run()
            {
            if(mStrAppKey.equals("0")){
                if (adInsertBaseListener!=null){
                    adInsertBaseListener.adInsertDidFail();
                }
                return;
            }


                try {
                    if (mAdWorker.isReady()) {
                        mAdWorker.show();
                    }else{

                        mAdWorker.load(mStrAppKey);
                    }
                } catch (Exception e) {
                }


            }
        } );
    }

    public void setListener(IAdInsertBaseListener listener)
    {
        adInsertBaseListener = listener;
    }


    public void startSplashAd(final String strAppId, final String strAppKey) {


    }


}

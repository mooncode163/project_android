package com.moonma.common;

import android.app.Activity;

import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.RelativeLayout;
import android.widget.Toast;

import org.json.JSONObject;

import com.moonma.common.IAdVideoBase;
import com.moonma.common.IAdVideoBaseListener;

import com.miui.zeus.mimo.sdk.ad.AdWorkerFactory;
import com.miui.zeus.mimo.sdk.ad.IVideoAdWorker;
import com.miui.zeus.mimo.sdk.listener.MimoVideoListener;
import com.xiaomi.ad.common.pojo.AdType;

import com.moonma.common.AdConfigXiaomi;

public class AdVideoXiaomi implements IAdVideoBase  {

    private static String TAG = "AdXiaomi";


    boolean isAdInit;
   FrameLayout framelayout;
   FrameLayout framelayoutVideo;
    Activity mainActivity;
    private   boolean sIsShow;
    private   int bannerOffsety;
    private   float bannerAlhpha;

    int adType;
    private IAdVideoBaseListener adVideoBaseListener;

    IVideoAdWorker mVideoAdWorker;

    public   void init(  Activity activity,FrameLayout layout)
    {
        mainActivity = activity;
        framelayout = layout;
        isAdInit = false;
    }

    public void setType(int type)
    {
        adType = type;
    }

     public void setAd()
    {

        if(isAdInit==false)
        {
            isAdInit = true;

            String strAppId = AdConfigXiaomi.main().appId;
            String strAppKey = AdConfigXiaomi.main().appKeyVideo;

            createVideoView();

            try {
                mVideoAdWorker = AdWorkerFactory.getVideoAdWorker(mainActivity, strAppKey, AdType.AD_PLASTER_VIDEO);
                mVideoAdWorker.setListener(new MimoVideoListener() {
                    @Override
                    public void onVideoStart() {
                        Log.e(TAG, "Video is start");
                        if(adVideoBaseListener!=null){
                            adVideoBaseListener.adVideoDidStart();
                        }
                    }

                    @Override
                    public void onVideoPause() {
                        Log.e(TAG, "Video is pause");

                    }

                    @Override
                    public void onVideoComplete() {
                        Log.e(TAG, "Video is complete");
                        closeVideoView();
                        if(adVideoBaseListener!=null){
                            adVideoBaseListener.adVideoDidFinish();
                        }
                    }

                    @Override
                    public void onAdPresent() {
                        Log.d(TAG, "AdVideoXiaomi onAdPresent");
                    }

                    @Override
                    public void onAdClick() { 
                         Log.d(TAG, "AdVideoXiaomi onAdClick");
                        closeVideoView();
                    }

                    @Override
                    public void onAdDismissed() {
                         Log.d(TAG, "AdVideoXiaomi onAdDismissed");
                        closeVideoView();
                    }

                    @Override
                    public void onAdFailed(String s) { 
                        Log.d(TAG, "AdVideoXiaomi onAdFailed "+s);
                        closeVideoView();
                        if(adVideoBaseListener!=null){
                            adVideoBaseListener.adVideoDidFail();
                        }
                    }

                    @Override
                    public void onAdLoaded() { 
                         Log.d(TAG, "AdVideoXiaomi onAdLoaded");
                        startPlayVideo();
                    }
                });
            } catch (Exception e) {
                e.printStackTrace();
            }

        }

    }

    void createVideoView()
    {
        //将adView添加到父控件中(注：该父控件不一定为您的根控件，只要该控件能通过addView能添加广告视图即可)
        RelativeLayout.LayoutParams rllp = new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.FILL_PARENT, RelativeLayout.LayoutParams.WRAP_CONTENT);
        rllp.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM);
        //rllp.addRule(RelativeLayout.CENTER_HORIZONTAL);


        // FrameLayout
        ViewGroup.LayoutParams framelayout_params =
                new ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT);
        framelayoutVideo = new FrameLayout(mainActivity);
        framelayoutVideo.setLayoutParams(framelayout_params);

        //framelayoutAd.addView(mBannerAd);
        framelayout.addView(framelayoutVideo, rllp);


        // adView.setVisibility(View.GONE);
        framelayoutVideo.setVisibility(View.GONE);
    }
    void closeVideoView()
    {
        framelayout.removeView(framelayoutVideo);
    }
    void startPlayVideo()
    {
        framelayoutVideo.setVisibility(View.VISIBLE);
        try {
        if (mVideoAdWorker.isReady()) {
            framelayoutVideo.removeAllViews();
        }
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    // show 耗时，不要放在主线程
                    mVideoAdWorker.show(framelayoutVideo);
                    mVideoAdWorker.play();
                } catch (Exception e) {
                }
            }
        }).start();

        } catch (Exception e) {
        }
    }

    
    public void show( )
    {
        try{
             mVideoAdWorker.recycle();
            if (!mVideoAdWorker.isReady()) {
                mVideoAdWorker.load();
            }
        } catch (Exception e) {
        }
    }

    public void setListener(IAdVideoBaseListener listener)
    {
        adVideoBaseListener = listener;
    }



}

package com.moonma.common;

import android.app.Activity;

import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.RelativeLayout;
import android.widget.Toast;

import org.json.JSONObject;

import com.moonma.common.IAdVideoBase;
import com.moonma.common.IAdVideoBaseListener;
import com.moonma.common.AdConfigAdView;

//adview
import com.kyview.interfaces.AdViewVideoListener;
import com.kyview.manager.AdViewVideoManager;

public class AdVideoAdView implements IAdVideoBase, AdViewVideoListener {

    private static String TAG = "AdVideo";

    String strAdAppId;
    boolean isAdInit;
    // FrameLayout framelayout;
    Activity mainActivity;
    private boolean sIsShow;
    private int bannerOffsety;
    private float bannerAlhpha;

    int adType;
    private IAdVideoBaseListener adVideoBaseListener;

    public void init(Activity activity, FrameLayout layout) {
        mainActivity = activity;
        // framelayout = layout;
        isAdInit = false;
    }

    public void setType(int type) {
        adType = type;
    }

    public void setAd() {

        if (isAdInit == false) {
            isAdInit = true;
            String strAppId = AdConfigAdView.main().appId;
            String strAppKey = AdConfigAdView.main().appKeyVideo;
            strAdAppId = strAppId;

            // 只请求广告，适用于预加载
            AdViewVideoManager.getInstance(mainActivity).requestAd(mainActivity, strAdAppId, this);

        }

    }

    public void show() {
        AdViewVideoManager.getInstance(mainActivity).playVideo(mainActivity, strAdAppId);
    }

    public void setListener(IAdVideoBaseListener listener) {
        adVideoBaseListener = listener;
    }

    @Override
    public void onAdFailed(String arg0) {
        Log.i("AdInstlActivity", "onAdFailed");

        if (adVideoBaseListener != null) {
            adVideoBaseListener.adVideoDidFail();
        }
    }

    @Override
    public void onAdRecieved(String arg0) {
        Log.i("AdInstlActivity", "onReceivedAd");

    }

    @Override
    public void onAdClose(String arg0) {

        Log.i("AdInstlActivity", "onAdDismiss");
    }

    @Override
    public void onAdReady(String s) {
        Log.i("AdInstlActivity", "onAdReady, pls show ad");
    }

    @Override
    public void onAdPlayEnd(String arg0, Boolean arg1) {

        Log.i("AdInstlActivity", "onAdPlayEnd");
        if (adVideoBaseListener != null) {
            adVideoBaseListener.adVideoDidFinish();
        }
    }

    @Override
    public void onAdPlayStart(String arg0) {
        Log.i("AdInstlActivity", "onAdPlayStart");
        if (adVideoBaseListener != null) {
            adVideoBaseListener.adVideoDidStart();
        }
    }

}

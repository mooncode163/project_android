package com.moonma.common;
import android.content.Context;

import com.miui.zeus.mimo.sdk.MimoSdk;
import com.moonma.common.AdConfigBase;
/**
 * Created by jaykie on 16/5/24.
 */
public class AdConfigXiaomi extends AdConfigBase{  
    private static AdConfigXiaomi _mian = null;
    static boolean isInitedSDK = false;
    public static AdConfigXiaomi main() {
        if(_mian==null){
            _mian = new AdConfigXiaomi();  
        }
        return _mian;
    }

    public void initSdk(Context ctx, String strAppId)
    {

        if(isInitedSDK){
            return;
        }
        // 如果担心sdk自升级会影响开发者自身app的稳定性可以关闭，
        // 但是这也意味着您必须得重新发版才能使用最新版本的sdk, 建议开启自升级
//        MimoSdk.setEnableUpdate(false);
        /**
         * new sdk
         */

        // 以下两个没有的话就按照以下传入
        final String APP_KEY = "fake_app_key";
        final String APP_TOKEN = "fake_app_token";

        MimoSdk.init(ctx,strAppId,APP_KEY,APP_TOKEN);
        MimoSdk.setDebugOn();
        // 正式上线时候务必关闭stage测试广告模式
        // MimoSdk.setStageOn();

        isInitedSDK = true;
    }
}

package com.moonma.common;



import android.app.Application;
import android.content.Context;
import android.content.res.Configuration;
import android.util.DisplayMetrics;
import android.util.Log;
import java.util.Map;

import com.moonma.common.AdConfigBase;


//mobvista
import com.mintegral.msdk.MIntegralConstans;
import com.mintegral.msdk.MIntegralSDK;
import com.mintegral.msdk.MIntegralUser;
import com.mintegral.msdk.out.MIntegralSDKFactory;


/**
 * Created by jaykie on 16/5/24.
 */
public class AdConfigMobVista extends AdConfigBase {
    private static AdConfigMobVista _mian = null;

    public static AdConfigMobVista main() {
        if (_mian == null) {
            _mian = new AdConfigMobVista();
        }
        return _mian;
    }
    public void onInit(Context context, String appId, String appKey) 
    {


//		if (LeakCanary.isInAnalyzerProcess(this)) {
//			// This process is dedicated to LeakCanary for heap analysis.
//			// You should not init your app in this process.
//			return;
//		}

		MIntegralConstans.DEBUG = true;

        //		LeakCanary.install(this);
        //		//检查ANR工具
        //		BlockCanary.install(this, new BlockCanaryContext()).start();
        
                Log.i("demo", "application oncreate");
        
                reportUser(33.0121,22.001);
                MIntegralConstans.DEBUG = true;
        
                // init sdk
                final MIntegralSDK sdk = MIntegralSDKFactory.getMIntegralSDK();
                // test appId and appKey
                // String appId = "104168";//"92762";
                // String appKey = "1c73843028601c9171e30f46ab0f21d3";//"936dcbdd57fe235fd7cf61c2e93da3c4";
                Map<String, String> map = sdk.getMTGConfigurationMap(appId, appKey);
                // if you modify applicationId, please add the following attributes,
                // otherwise it will crash
                // map.put(MIntegralConstans.PACKAGE_NAME_MANIFEST, "your AndroidManifest
                // package value");
        
                sdk.init(map, context);
                //update user
                reportUser(111.0121,-15.001);
    }



    /**
     * report current user info,this can Raise Revenue
     */
	public static void reportUser(double lat , double lng){
        MIntegralUser mIntegralUser = new MIntegralUser();
        // 1(pay),0(no pay)，if unkonw you can not set
        mIntegralUser.setPay(1);
        // 1male,2fmale(int类型),if unkonw you can not set
        mIntegralUser.setGender(2);
        // set current user age,if unkonw you can not set
        mIntegralUser.setAge(28);
        //Custom parameters
        mIntegralUser.setCustom("Custom parameters");
        //set user longitude,if unkonw you can not set
        mIntegralUser.setLng(lng);
        //set user latitude,if unkonw you can not set
        mIntegralUser.setLat(lat);
        MIntegralSDKFactory.getMIntegralSDK().reportUser(mIntegralUser);
    }
    
}

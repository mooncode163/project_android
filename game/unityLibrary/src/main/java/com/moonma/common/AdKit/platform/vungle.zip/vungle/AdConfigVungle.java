package com.moonma.common;
import android.content.Context;
import android.util.Log;

import com.moonma.common.AdConfigBase;
import com.vungle.warren.InitCallback;
import com.vungle.warren.Vungle;

/**
 * Created by jaykie on 16/5/24.
 */
public class AdConfigVungle extends AdConfigBase{

    private  String TAG = "AdConfigVungle";
    static boolean isInitedSDK = false;

    private static AdConfigVungle _mian = null;
    public static AdConfigVungle main() {
        if(_mian==null){
            _mian = new AdConfigVungle();
        }
        return _mian;
    }

    public void onInit(Context context, String appId, String appKey)
    {
        if(isInitedSDK){
            return;
        }
        Log.d(TAG,"Vungle init appId="+appId);
        isInitedSDK = true;
        //这里的Context 必须是getApplicationContext 不能Activity 不然会初始化失败
        Vungle.init(appId, context, new InitCallback() {
            @Override
            public void onSuccess() {
               Log.d(TAG, "InitCallback - onSuccess");

            }
            @Override
            public void onError(Throwable throwable) {
               Log.d(TAG, "InitCallback - onError: " + throwable.getLocalizedMessage());
            }

            @Override
            public void onAutoCacheAdAvailable(final String placementReferenceID) {
             Log.d(TAG, "InitCallback - onAutoCacheAdAvailable" +
                        "\n\tPlacement Reference ID = " + placementReferenceID);
                // SDK will request auto cache placement ad immediately upon initialization
                // This callback is triggered every time the auto-cached placement is available
                // This is the best place to add your own listeners and propagate them to any UI logic bearing class

            }
        });
    }
}




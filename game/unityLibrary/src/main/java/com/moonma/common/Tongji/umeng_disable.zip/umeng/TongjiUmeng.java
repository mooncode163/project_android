//package com.czt.util;
package com.moonma.common;
import android.content.Context;

import com.moonma.common.ITongjiBase;
public class TongjiUmeng implements ITongjiBase {
	 

         public void Init(final Context context, String appKey, String channel)
         {

         }

    public  void onPause(Context context ) {
        //@moon

    }

    public void onResume(Context context) {

    }
}

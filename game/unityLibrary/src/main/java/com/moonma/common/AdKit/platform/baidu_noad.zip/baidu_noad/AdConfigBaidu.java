package com.moonma.common;
import com.moonma.common.AdConfigBase;
/**
 * Created by jaykie on 16/5/24.
 */
public class AdConfigBaidu extends AdConfigBase{  
    private static AdConfigBaidu _mian = null; 
    public static AdConfigBaidu main() {
        if(_mian==null){
            _mian = new AdConfigBaidu();  
        }
        return _mian;
    }
}

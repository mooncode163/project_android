package com.moonma.common;

import android.app.Activity;

import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.RelativeLayout;

import com.moonma.common.IAdBannerBase;
import com.moonma.common.IAdBannerBaseListener;
import com.moonma.common.AdConfigAdView;

//adview
import com.kyview.InitConfiguration;
import com.kyview.interfaces.AdViewBannerListener;
import com.kyview.manager.AdViewBannerManager;

public class AdBannerAdView implements IAdBannerBase,AdViewBannerListener {

    // 自定义单一平台广告视图对象
    private static String TAG = "AdBanner";

    FrameLayout framelayout;
    Activity mainActivity;
    private boolean sIsShow;
    private int bannerOffsety;
    private float bannerAlhpha;
    View viewAd;

    // AdView adView;
    FrameLayout framelayoutAd;
    IAdBannerBaseListener adBannerBaseListener;
    boolean isAdInit;

    public void init(Activity activity, FrameLayout layout) {
        mainActivity = activity;
        framelayout = layout;
        isAdInit = false;
        sIsShow = false;
        bannerOffsety = 0;

    }

    public void setAd() {
        if (isAdInit == false) {
            isAdInit = true;

            String strAppId = AdConfigAdView.main().appId;
            String strAppKey = AdConfigAdView.main().appKeyBanner;

            Log.d(TAG, "adview banner id=" + strAppId + " key=" + strAppKey);
            if(strAppId==null) {
                return;
            }
//            if (adBannerBaseListener != null) {
//                adBannerBaseListener.onLoadAdFail();
//                return;
//            }


            viewAd = AdViewBannerManager.getInstance(mainActivity).getAdViewLayout(mainActivity, strAppId);
            if (null != viewAd) {
                ViewGroup parent = (ViewGroup) viewAd.getParent();
                if (parent != null) {
                    parent.removeAllViews();
                }
            }
            AdViewBannerManager.getInstance(mainActivity).requestAd(mainActivity, strAppId, this);
            viewAd.setTag(strAppId);

            // 将adView添加到父控件中(注：该父控件不一定为您的根控件，只要该控件能通过addView能添加广告视图即可)
            RelativeLayout.LayoutParams rllp = new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.FILL_PARENT,
                    RelativeLayout.LayoutParams.WRAP_CONTENT);
            rllp.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM);
            // rllp.addRule(RelativeLayout.CENTER_HORIZONTAL);

            // FrameLayout
            ViewGroup.LayoutParams framelayout_params = new ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT);
            framelayoutAd = new FrameLayout(mainActivity);
            framelayoutAd.setLayoutParams(framelayout_params);

            framelayoutAd.addView(viewAd);
            framelayout.addView(framelayoutAd, rllp);
 
            framelayoutAd.setVisibility(View.GONE);

        }

    }

    public void setAlpha(float alpha) {

        bannerAlhpha = alpha;
        if (mainActivity == null) {
            return;
        }
        mainActivity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (bannerAlhpha < 1.0) {
                    // bannerAlhpha =0;
                }
                framelayoutAd.setAlpha(bannerAlhpha);

            }
        });

    }

    public void show(boolean isShow) {
        sIsShow = isShow;

        if (mainActivity == null) {
            return;
        }

        mainActivity.runOnUiThread(new Runnable() {
            @Override
            public void run() {

                if (viewAd == null) {
                    return;
                }
                if (sIsShow) {

                    // bv.loadAD();
                    framelayoutAd.setVisibility(View.VISIBLE);

                } else {

                    framelayoutAd.setVisibility(View.GONE);
                }
            }
        });

    }

    public void layoutSubView(int w, int h) {
        setOffsetY(bannerOffsety);

    }

    public void setOffsetY(int y) {

        bannerOffsety = y;
        //
        //
        if ((viewAd == null) || (framelayout == null) || (mainActivity == null)) {
            return;
        }
        mainActivity.runOnUiThread(new Runnable() {
            @Override
            public void run() {

                int screen_w = framelayout.getWidth();
                int w = viewAd.getWidth();
                int screen_h = framelayout.getHeight();
                int h = viewAd.getHeight();
                int banner_h = 150;
                if(h<banner_h)
                {
                    //第一次大小会显示56 调整
                    h = banner_h;
                }
                Log.d(TAG, "adview banner w=" + w + " h=" + h);
                int x = (screen_w - w) / 2;
                int y = screen_h - h - bannerOffsety-ScreenUtil.getBottomNavigationBarHeight();

                if (h == 0) {
                    // 显示到屏幕外
                    // y = screen_h;

                }
                // adView.setX(x);
                // adView.setY(y);

                framelayoutAd.setX(x);
                framelayoutAd.setY(y);

              
               // viewAd.setY(0);
              //  viewAd.bringToFront();
                framelayoutAd.bringToFront();
            }
        });

    }

    public void setListener(IAdBannerBaseListener listener) {
        adBannerBaseListener = listener;

    }

    void onAdFinish()
    {
        if (adBannerBaseListener != null) {
            int w, h;
            w = viewAd.getWidth();
            h = viewAd.getHeight();
            setOffsetY(bannerOffsety);
            adBannerBaseListener.onReceiveAd(w, h);
        }
    }
    @Override
    public void onAdClick(String arg0) {
        Log.i("AdBannerActivity", "onAdClick");
    }

    @Override
    public void onAdClose(String arg0) {
        Log.i(TAG, "onAdClose");
        // if (null != layout)
        //     layout.removeView(layout.findViewWithTag(arg0));
    }

    @Override
    public void onAdDisplay(String arg0) {
        Log.i(TAG, "onDisplayAd");
        onAdFinish();

    }

    @Override
    public void onAdFailed(String arg0) {
        Log.i(TAG, "onAdFailed");
        if (adBannerBaseListener != null) {
            adBannerBaseListener.onLoadAdFail();
        }
    }

    @Override
    public void onAdReady(String arg0) {
        Log.i(TAG, "onAdReady");
        onAdFinish();
    }

    // @Override
    // protected void onDestroy() {
    // try {
    // super.onDestroy();
    // if (null != layout)
    // layout.removeAllViews();
    // } catch (Exception e) {
    // e.printStackTrace();
    // }
    // }
}

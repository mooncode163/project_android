package com.moonma.common;
import com.moonma.common.AdConfigBase;
/**
 * Created by jaykie on 16/5/24.
 */
public class AdConfigChsj extends AdConfigBase{  
    private static AdConfigChsj _mian = null; 
    public static AdConfigChsj main() {
        if(_mian==null){
            _mian = new AdConfigChsj();  
        }
        return _mian;
    }
}

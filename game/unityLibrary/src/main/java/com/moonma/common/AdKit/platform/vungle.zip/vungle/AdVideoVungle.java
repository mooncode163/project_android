package com.moonma.common;

import android.app.Activity;

import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.RelativeLayout;
import android.widget.Toast;

import org.json.JSONObject;

import com.moonma.common.IAdVideoBase;
import com.moonma.common.IAdVideoBaseListener;
import com.moonma.common.AdConfigVungle;

import com.vungle.warren.AdConfig;
import com.vungle.warren.InitCallback;
import com.vungle.warren.LoadAdCallback;
import com.vungle.warren.PlayAdCallback;
import com.vungle.warren.Vungle;
import com.vungle.warren.VungleNativeAd;
import com.vungle.warren.Vungle.Consent;
import com.vungle.warren.error.VungleException;

public class AdVideoVungle implements IAdVideoBase  {
 private   String TAG = this.getClass().getSimpleName();


    private static int ordinal = 1;

   static boolean isAdInit;
    Activity mainActivity;
    private   boolean sIsShow;
    private   int bannerOffsety;
    private   float bannerAlhpha;
    int adType;

   boolean isAutoShow;
    boolean isLoading;
    private IAdVideoBaseListener adVideoBaseListener;

    public   void init(  Activity activity,FrameLayout layout)
    {
        mainActivity = activity;
        //framelayout = layout;
        isAdInit = false;
    }

    public void setType(int type)
    {
        adType = type;
    }
     public void setAd()
    {

        if(isAdInit==false)
        {
            isAdInit = true;
            String strAppId = AdConfigVungle.main().appId;
            loadAd(false);
        }

    }

    public void show() {

        mainActivity.runOnUiThread( new Runnable()
        {
            @Override
            public void run()
            {
                String strAppKey = AdConfigVungle.main().appKeyVideo;
                if (Vungle.isInitialized() && Vungle.canPlayAd(strAppKey)) {
                    showAd();
                }else {
                    loadAd(true);
                }
            }
        } );

    }

    public void setListener(IAdVideoBaseListener listener)
    {
        adVideoBaseListener = listener;
    }


    public void loadAd(boolean autoshow) {
        isAutoShow = autoshow;
        if(isLoading){
            Log.d(TAG,"ad is loading,waiting...");
            return;
        }

        String strAppKey = AdConfigVungle.main().appKeyVideo;
        Log.d(TAG,"loadAd strAppKey="+strAppKey);
        if (Vungle.isInitialized() )
        {
            Log.d(TAG,"start loadAd ");
            Vungle.loadAd(strAppKey, vungleLoadAdCallback);
            isLoading = true;
        }else{
            Log.d(TAG,"  loadAd not isInitialized ");
            isLoading = false;
        }
    }
    public void showAd() {
        String strAppKey = AdConfigVungle.main().appKeyVideo;
        if (Vungle.isInitialized() && Vungle.canPlayAd(strAppKey)) {
            // Play Dynamic Template ad
            Vungle.playAd(strAppKey, null, vunglePlayAdCallback);
        }
    }
    private final PlayAdCallback vunglePlayAdCallback = new PlayAdCallback() {
        @Override
        public void onAdStart(final String placementReferenceID) {
            Log.d(TAG, "PlayAdCallback - onAdStart" +
                    "\n\tPlacement Reference ID = " + placementReferenceID);

            if(adVideoBaseListener!=null){
                adVideoBaseListener.adVideoDidStart();
            }
        }

        @Override
        public void onAdEnd(final String placementReferenceID, final boolean completed, final boolean isCTAClicked) {
            Log.d(TAG, "PlayAdCallback - onAdEnd" +
                    "\n\tPlacement Reference ID = " + placementReferenceID +
                    "\n\tView Completed = " + completed + "" +
                    "\n\tDownload Clicked = " + isCTAClicked);

            if(adVideoBaseListener!=null){
                adVideoBaseListener.adVideoDidFinish();
            }
        }

        @Override
        public void onError(final String placementReferenceID, Throwable throwable) {
            Log.d(TAG, "PlayAdCallback - onError" +
                    "\n\tPlacement Reference ID = " + placementReferenceID +
                    "\n\tError = " + throwable.getLocalizedMessage());
//

//            if(adVideoBaseListener!=null){
//                adVideoBaseListener.adVideoDidFail();
//            }
        }
    };

    private final LoadAdCallback vungleLoadAdCallback = new LoadAdCallback() {
        @Override
        public void onAdLoad(final String placementReferenceID) {

            Log.d(TAG,"LoadAdCallback - onAdLoad" +
                    "\n\tPlacement Reference ID = " + placementReferenceID);
//

            isLoading = false;
            if(isAutoShow){
                showAd();
            }

        }

        @Override
        public void onError(final String placementReferenceID, Throwable throwable) {
            Log.d(TAG, "LoadAdCallback - onError" +
                    "\n\tPlacement Reference ID = " + placementReferenceID +
                    "\n\tError = " + throwable.getLocalizedMessage());

            isLoading = false;
            if(adVideoBaseListener!=null){
                adVideoBaseListener.adVideoDidFail();
            }
        }
    };


}

package com.moonma.common;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;

import com.miui.zeus.mimo.sdk.MimoSdk;
import com.moonma.common.IAdSplashBase;
import com.moonma.common.AdConfig;


import com.miui.zeus.mimo.sdk.ad.AdWorkerFactory;
import com.miui.zeus.mimo.sdk.ad.IAdWorker;
import com.miui.zeus.mimo.sdk.listener.MimoAdListener;
import com.xiaomi.ad.common.pojo.AdType;

import com.moonma.common.AdConfigXiaomi;
/**
 * Created by jaykie on 2017/5/4.
 */

public class AdSplashXiaomi implements IAdSplashBase {

    private static String TAG = "AdXiaomi";

    FrameLayout framelayout;
    Activity mainActivity;
    public boolean canJump = false;
    FrameLayout frameLayoutAd;
    //以下的POSITION_ID 需要使用您申请的值替换下面内容
    private static final String POSITION_ID = "b373ee903da0c6fc9c9da202df95a500";
    private IAdWorker mWorker;


    //获取当前使用第几天 从1开始
    int getDayIndexOfUse() {
        int index = 1;
        long second_first_use = 0;
        String pkey_firstuse_second = "key_app_first_use_second";
        String pkeyfirstuse = "key_app_first_use";

        SharedPreferences prefs = mainActivity.getSharedPreferences(
                "cocos2dx_app", Context.MODE_PRIVATE);
        boolean isFirstUse = !prefs.getBoolean(pkeyfirstuse, false);
        if (isFirstUse) {
            SharedPreferences.Editor editor = prefs.edit();
            editor.putBoolean(pkeyfirstuse, true);
            editor.commit();

            second_first_use = System.currentTimeMillis() / 1000;
//

            //默认设置为软件解码
//            int mode = 2;//DecoderMode.UM;
            editor.putLong(pkey_firstuse_second, second_first_use);
            editor.commit();


        }


        second_first_use = prefs.getLong(pkey_firstuse_second, 0);
        long second_cur = System.currentTimeMillis() / 1000;
        index = (int) ((second_cur - second_first_use) / (3600 * 24));
        if (index < 0) {
            index = 0;
        }
        index++;

        return index;
    }


    int getNoAdDay() {
        int index = 1;
        String pkey = "key_no_ad_day";
        SharedPreferences prefs = mainActivity.getSharedPreferences(
                "cocos2dx_app", Context.MODE_PRIVATE);

        index = prefs.getInt(pkey, 1);
        return index;
    }

    boolean isEnableAd() {

        String pkey = "key_enable_splash";
        SharedPreferences prefs = mainActivity.getSharedPreferences(
                "cocos2dx_app", Context.MODE_PRIVATE);

        boolean ret = prefs.getBoolean(pkey, true);
        return ret;
    }

    public void init(Activity activity, FrameLayout layout) {
        mainActivity = activity;
        framelayout = layout;


    }

    public void showAdSplashByInsert() {

    }

    public boolean isNoAd() {
        String pkey = "key_app_no_ad";
        SharedPreferences prefs = mainActivity.getSharedPreferences(
                "cocos2dx_app", Context.MODE_PRIVATE);

        boolean ret = prefs.getBoolean(pkey, false);
        return ret;
    }


    public void checkSdkReady()
    {
        long tickReady = System.currentTimeMillis();
        long timeOut = 2000;
        long timeRuning= 0;
        while (true)
        {
            if(MimoSdk.isSdkReady())
            {
                break;
            }
            timeRuning = System.currentTimeMillis()-tickReady;
            if(timeRuning>timeOut){
                Log.d(TAG,"ready time out");
                break;
            }
        }
        tickReady = System.currentTimeMillis()-tickReady;
        Log.d(TAG,"tickReady="+tickReady+"ms");

    }

    public void showAdSplash()
    {
        String APP_ID = "2882303761517411490"; 
      

        String strAppId = "";
        String strAppKeySplash = "";

        String pkey_splash_souce = "key_splash_souce";
        String pkey_splash_appid = "key_splash_appid";
        String pkey_splash_appkey = "key_splash_appkey";
        SharedPreferences prefs = mainActivity.getSharedPreferences(
                "cocos2dx_app", Context.MODE_PRIVATE);

        strAppId = prefs.getString(pkey_splash_appid, "0");
        strAppKeySplash = prefs.getString(pkey_splash_appkey, "0");

        AdConfig adConfig = AdConfig.Main(mainActivity);
        strAppId = adConfig.GetAppId(Source.XIAOMI);
        strAppKeySplash = adConfig.GetSplashId(Source.XIAOMI);

        //fetchSplashAD(this, container, skipView, strAppId, strAppKeySplash, this, 0);
        Log.i(TAG, "splash id="+strAppId+ " key="+strAppKeySplash);
// R.drawable.default_splash

        if(strAppId=="0"){
            //next();
             Log.d(TAG, "AdSplashXiaomi strAppId is 0 return ");
            return;
        }


          if(!isEnableAd())
        {
             Log.d(TAG, "AdSplashXiaomi isEnableAd is false return ");
            return;
        }

        if((getDayIndexOfUse()<=getNoAdDay())||isNoAd()) {
             Log.d(TAG, "AdSplashXiaomi getNoAdDay or isNoAd return ");
            return;
        }

        checkSdkReady();

        //@moon res_id = R.drawable.default_splash
        //用代码获取资源id 解除R.java对包名的依赖
       

        ViewGroup.LayoutParams framelayout_params =
                new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT);

        frameLayoutAd = new FrameLayout(mainActivity);

        frameLayoutAd.setLayoutParams(framelayout_params);

        framelayout.addView(frameLayoutAd);




        try {
            mWorker = AdWorkerFactory.getAdWorker(mainActivity, frameLayoutAd, new MimoAdListener() {
                @Override
                public void onAdPresent() {
                    // 开屏广告展示
                    Log.d(TAG, "AdSplashXiaomi onAdPresent");
                }

                @Override
                public void onAdClick() {
                    //用户点击了开屏广告
                    Log.d(TAG, "AdSplashXiaomi onAdClick");
                    next();
                }

                @Override
                public void onAdDismissed() {
                    //这个方法被调用时，表示从开屏广告消失。
                    Log.d(TAG, "AdSplashXiaomi onAdDismissed");
                    next();
                }

                @Override
                public void onAdFailed(String s) {
                    Log.e(TAG, "AdSplashXiaomi onAdFailed : " + s);
                    next();
                }

                @Override
                public void onAdLoaded() {
                    //do nothing
                    Log.d(TAG, "AdSplashXiaomi onAdLoaded");
                }
            }, AdType.AD_SPLASH);

            mWorker.loadAndShow(strAppKeySplash);
        } catch (Exception e) {
            e.printStackTrace();
            next();

        }

    }


    /**
     * 设置一个变量来控制当前开屏页面是否可以跳转，当开屏广告为普链类广告时，点击会打开一个广告落地页，此时开发者还不能打开自己的App主页。当从广告落地页返回以后，
     * 才可以跳转到开发者自己的App主页；当开屏广告是App类广告时只会下载App。
     */
    private void next() {
        framelayout.removeView(frameLayoutAd);

        if (canJump) {
//            this.startActivity(new Intent(this,UnityPlayerActivity.class));//UnityPlayerActivity MainActivity
//            this.finish();

        } else {
            canJump = true;
        }
    }

//    @Override
//    protected void onPause() {
//        super.onPause();
//        canJump = false;
//    }
//
//    @Override
//    protected void onResume() {
//        super.onResume();
//        if (canJump) {
//            next();
//        }
//        canJump = true;
//    }

    //@moon
}

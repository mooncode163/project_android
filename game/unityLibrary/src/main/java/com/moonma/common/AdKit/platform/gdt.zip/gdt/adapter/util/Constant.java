package com.qq.e.union.demo.adapter.util;

public class Constant {
  public static final int VALUE_NO_ECPM = -1;
}

package com.moonma.common;

import android.app.Activity;

import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.moonma.common.AdBannerBase;
import com.moonma.common.IAdBannerBase;
import com.moonma.common.IAdBannerBaseListener;
import com.moonma.common.ImageLoadTask;
import com.moonma.common.AdConfigMobVista;
import com.moonma.common.ScreenUtil;

import com.mintegral.msdk.MIntegralConstans;
import com.mintegral.msdk.MIntegralSDK;
import com.mintegral.msdk.out.Campaign;
import com.mintegral.msdk.out.Frame;
import com.mintegral.msdk.out.MIntegralSDKFactory;
import com.mintegral.msdk.out.MtgNativeHandler;
import com.mintegral.msdk.out.NativeListener.NativeAdListener;
import com.mintegral.msdk.out.NativeListener.Template;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

//用native 做banner
public class AdBannerMobVista extends AdBannerBase implements IAdBannerBase {

    // 自定义单一平台广告视图对象
    private static String TAG = "AdBanner";
    public static final String UNIT_ID = "21306";
    FrameLayout framelayout;
    Activity mainActivity;
    private int bannerOffsety;
    private float bannerAlhpha; 
    // AdView adView;
    FrameLayout framelayoutAd;
    IAdBannerBaseListener adBannerBaseListener;
    boolean isAdInit;
    private MtgNativeHandler nativeHandle;
    private RelativeLayout mRl_Root;
    private ImageView mIvIcon;
    private ImageView mIvImage;
    private TextView mTvAppName;
    private TextView mTvAppDesc;
    private TextView mTvCta;
    private ProgressBar mProgressBar;
    int mainLayout;
    Handler mHandlerRefresh;
    long timeRefresh = 4000;//ms

    int banner_height = 136;

    public void init(Activity activity, FrameLayout layout) {
        mainActivity = activity;
        framelayout = layout;
        isAdInit = false;
        isAdShow = false;
        bannerOffsety = 0;
        Resources resources = mainActivity.getResources();
        //获取布局文件的Id
        mainLayout = resources.getIdentifier("mintegral_native_banner_activity", "layout", mainActivity.getPackageName());
        initView();

        //定时更新
        mHandlerRefresh = new Handler();
        Runnable r = new Runnable() {
            @Override
            public void run() {
                Log.d(TAG,"mHandlerRefresh isAdShow="+isAdShow);
                if(isAdShow)
                {
                    //do something
                    //每隔1s循环执行run方法
                    //showLoadding();
                    loadNative();
                }

                mHandlerRefresh.postDelayed(this, timeRefresh);
            }
        };

        mHandlerRefresh.postDelayed(r, timeRefresh);//延时100毫秒
    }

    public void setAd() {

//        if (adBannerBaseListener != null) {
//            adBannerBaseListener.onLoadAdFail();
//            return;
//        }
        showLoadding();
        loadNative();

    }

    public void setAlpha(float alpha) {

    }

    public void show(boolean isShow) {
        isAdShow = isShow;
Log.d(TAG,"ad show isAdShow="+isAdShow);
        if (mainActivity == null) {
            return;
        }

        mainActivity.runOnUiThread(new Runnable() {
            @Override
            public void run() {

//                if (bv == null) {
//                    return;
//                }
                if (isAdShow) {

                    // bv.loadAD();
                    framelayoutAd.setVisibility(View.VISIBLE);

                } else {

                    framelayoutAd.setVisibility(View.GONE);
                }
            }
        });
    }

    public void layoutSubView(int w, int h) {
        setOffsetY(bannerOffsety);

    }

    public void setOffsetY(int y) {
        bannerOffsety = y;
//
//
        if ((framelayout == null) || (mainActivity == null)) {
            return;
        }
        mainActivity.runOnUiThread(new Runnable() {
            @Override
            public void run() {


                ViewGroup.LayoutParams layout = framelayoutAd.getLayoutParams();
                int screen_w = framelayout.getWidth();
                int screen_h = framelayout.getHeight();

                int w = framelayoutAd.getWidth();
                int h = framelayoutAd.getHeight();

                int x = (screen_w - w) / 2;
                x=0;
                int y = screen_h - h - bannerOffsety-ScreenUtil.getBottomNavigationBarHeight();


                framelayoutAd.setX(x);
                framelayoutAd.setY(y);



                framelayoutAd.bringToFront();
            }
        });
    }
    public String getAdId() {
        String strAppKey = AdConfigMobVista.main().appKeyBanner;
        return strAppKey;
    }


    public void showLoadding() {
      //  mProgressBar.setVisibility(View.VISIBLE);
        mRl_Root.setVisibility(View.GONE);
    }

    public void hideLoadding() {
       mProgressBar.setVisibility(View.GONE);
        mRl_Root.setVisibility(View.VISIBLE);
    }

    public void preloadNative() {
        MIntegralSDK sdk = MIntegralSDKFactory.getMIntegralSDK();
        Map<String, Object> preloadMap = new HashMap<String, Object>();
        String strAppKey = getAdId();
        preloadMap.put(MIntegralConstans.PROPERTIES_LAYOUT_TYPE, MIntegralConstans.LAYOUT_NATIVE);
        preloadMap.put(MIntegralConstans.PROPERTIES_UNIT_ID, strAppKey);
        List<Template> list = new ArrayList<Template>();
        list.add(new Template(MIntegralConstans.TEMPLATE_MULTIPLE_IMG, 1));
        preloadMap.put(MIntegralConstans.NATIVE_INFO, MtgNativeHandler.getTemplateString(list));
        sdk.preload(preloadMap);

    }


    private void loadNative() {
        String strAppKey = getAdId();
        Log.d(TAG, "loadNative strAppKey:" + strAppKey);
        Map<String, Object> properties = MtgNativeHandler.getNativeProperties(strAppKey);
        nativeHandle = new MtgNativeHandler(properties, mainActivity);
        nativeHandle.addTemplate(new Template(MIntegralConstans.TEMPLATE_MULTIPLE_IMG, 1));
        nativeHandle.setAdListener(new NativeAdListener() {

            @Override
            public void onAdLoaded(List<Campaign> campaigns, int template) {
                hideLoadding();
                fillBannerLayout(campaigns);
                preloadNative();


            }

            @Override
            public void onAdLoadError(String message) {
                Log.e(TAG, "onAdLoadError:" + message);
                if (adBannerBaseListener != null) {
                    adBannerBaseListener.onLoadAdFail();
                }
            }

            @Override
            public void onAdFramesLoaded(List<Frame> list) {

            }

            /**
             * called when the ads  be shown
             */
            @Override
            public void onLoggingImpression(int adsourceType) {
                if (adBannerBaseListener != null) {
                    int w, h;
                    w = framelayoutAd.getWidth();
                    h = framelayoutAd.getHeight();
                    Log.d(TAG, "onLoggingImpression:" + w+" h="+h);
                    adBannerBaseListener.onReceiveAd(w, h);

                    setOffsetY(bannerOffsety);
                }
            }

            @Override
            public void onAdClick(Campaign campaign) {
                Log.e(TAG, "onAdClick");
            }
        });
        nativeHandle.load();
    }

    void initView()
    {
        // 将adView添加到父控件中(注：该父控件不一定为您的根控件，只要该控件能通过addView能添加广告视图即可)
        RelativeLayout.LayoutParams rllp = new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.FILL_PARENT,
                RelativeLayout.LayoutParams.WRAP_CONTENT);
        rllp.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM);
        // rllp.addRule(RelativeLayout.CENTER_HORIZONTAL);

        // FrameLayout
        ViewGroup.LayoutParams framelayout_params = new ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        framelayoutAd = new FrameLayout(mainActivity);
        framelayoutAd.setLayoutParams(framelayout_params);


        framelayout.addView(framelayoutAd, rllp);

        // adView.setVisibility(View.GONE);
        //framelayoutAd.setVisibility(View.GONE);

        Resources resources = mainActivity.getResources();
        LayoutInflater inflater = LayoutInflater.from(mainActivity);
        //测试一id，null，false
        View view= inflater.inflate(mainLayout,null,false);
        framelayoutAd.addView(view);
        int resId = resources.getIdentifier("mintegral_banner_rl_root", "id", mainActivity.getPackageName());
        mRl_Root = (RelativeLayout) view.findViewById(resId);
        resId = resources.getIdentifier("mintegral_banner_iv_icon", "id", mainActivity.getPackageName());
        mIvIcon = (ImageView) view.findViewById(resId);
        resId = resources.getIdentifier("mintegral_banner_tv_title", "id", mainActivity.getPackageName());
        mTvAppName = (TextView) view.findViewById(resId);
        resId = resources.getIdentifier("mintegral_banner_tv_app_desc", "id", mainActivity.getPackageName());
        mTvAppDesc = (TextView) view.findViewById(resId);
        resId = resources.getIdentifier("mintegral_banner_tv_cta", "id", mainActivity.getPackageName());
        mTvCta = (TextView) view.findViewById(resId);
        resId = resources.getIdentifier("mintegral_banner_progress", "id", mainActivity.getPackageName());
        mProgressBar = (ProgressBar) view.findViewById(resId);
        mProgressBar.setVisibility(View.GONE);

    }
//https://www.cnblogs.com/jacksonwj/p/5930161.html
    protected void fillBannerLayout(List<Campaign> campaigns) {
        if (campaigns != null && campaigns.size() > 0) {
            Campaign campaign = campaigns.get(0);
           if (!TextUtils.isEmpty(campaign.getIconUrl())) {
              new ImageLoadTask(campaign.getIconUrl()) {
                  @Override
                  public void onRecived(Drawable result) {
                       mIvIcon.setImageDrawable(result);
                    }
               }.execute();
           }

            mTvAppName.setText(campaign.getAppName() + "");
           mTvAppDesc.setText(campaign.getAppDesc() + "");
           mTvCta.setText(campaign.getAdCall());
           nativeHandle.registerView(framelayoutAd, campaign);
        }
    }
    public void setListener(IAdBannerBaseListener listener) {
        adBannerBaseListener = listener;
    }

}

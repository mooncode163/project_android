package com.moonma.common;

import android.app.Activity;

import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.RemoteException;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.moonma.common.IIAPBase;
import com.moonma.common.IIAPBaseListener;
import com.xiaomi.gamecenter.sdk.MiCommplatform;
import com.xiaomi.gamecenter.sdk.MiErrorCode;
import com.xiaomi.gamecenter.sdk.OnLoginProcessListener;
import com.xiaomi.gamecenter.sdk.OnPayProcessListener;
import com.xiaomi.gamecenter.sdk.entry.MiAccountInfo;
import com.xiaomi.gamecenter.sdk.entry.MiAppInfo;
import com.xiaomi.gamecenter.sdk.entry.MiBuyInfo;


import org.json.JSONObject;

import java.util.UUID;


public class IAPXiaomi implements IIAPBase ,OnPayProcessListener,OnLoginProcessListener {

    // 自定
    private static String TAG = "IAP";

    Activity mainActivity;
    IIAPBaseListener iapBaseListener;
    private static MiAccountInfo accountInfo;
    String strProduct;
    public void init(Activity activity) {
        mainActivity = activity;

        //initSDK(mainActivity);
    }

    public static void initSDK(android.content.Context context)
    {
        AdConfig adConfig = AdConfig.Main(context);
        String appid = adConfig.GetAppId(Source.XIAOMI);
        String appkey = adConfig.GetAppKey(Source.XIAOMI);
        Log.d(TAG," appid ="+appid+" appkey="+appkey);
        MiAppInfo appInfo;
        /** SDK initialize */
        appInfo = new MiAppInfo();
        appInfo.setAppId(appid);// 2882303761517596419
        appInfo.setAppKey(appkey);// 5211759627419

        //demo
//        appInfo.setAppId( "2882303761517543214" );
//        appInfo.setAppKey( "5751754320214" );

        MiCommplatform.Init(context, appInfo );

//		DemoUtils.intiTestImg( this );
    }

    public  void StartBuy(String product)
    {
        strProduct = product;
        boolean islogin = MiCommplatform.getInstance().isMiAccountLogin();
        if(islogin){
            doBuy(product);
        }else{
            //先登陆
            onLogin();
        }
    }
    public  void RestoreBuy(String product)
    {
        onLogin();
    }

    public void setListener(IIAPBaseListener listener) {
        iapBaseListener = listener;
    }


    private MiBuyInfo createMiBuyInfo( String productCode, int count )
    {
        MiBuyInfo miBuyInfo = new MiBuyInfo();
        miBuyInfo.setProductCode( productCode );
        miBuyInfo.setCount( count );
        miBuyInfo.setCpOrderId( UUID.randomUUID().toString() );

        return miBuyInfo;
    }

    public  void doBuy(String product)
    {
        MiBuyInfo miBuyInfo = createMiBuyInfo(product,1);//noad  unity.demo_1
        try
        {
            MiCommplatform.getInstance().miUniPay(mainActivity, miBuyInfo, this);
        }
        catch ( RemoteException e )
        {
            e.printStackTrace();
        }
    }

    void onLogin()
    {
        // login
        MiCommplatform.getInstance().miLogin(mainActivity,this );
    }


    @Override
    public void finishLoginProcess( int arg0, MiAccountInfo arg1 )
    {
        if ( MiErrorCode.MI_XIAOMI_PAYMENT_SUCCESS == arg0 )
        {
            accountInfo = arg1;
            doBuy(strProduct);
        }

        else
        {
            //login_failed
            Toast.makeText(mainActivity, "登陆失败，请重试！", Toast.LENGTH_SHORT ).show();

        }
    }
    @Override
    public void finishPayProcess( int arg0 )
    {
        switch( arg0 )
        {

            case MiErrorCode.MI_XIAOMI_PAYMENT_SUCCESS:
                if(iapBaseListener!=null){
                    iapBaseListener.onBuyDidFinish();
                }
                break;
            case MiErrorCode.MI_XIAOMI_PAYMENT_ERROR_CANCEL:

                break;
            case MiErrorCode.MI_XIAOMI_PAYMENT_ERROR_PAY_CANCEL:
                if(iapBaseListener!=null){
                    //iapBaseListener.onBuyDidCancel();
                }
                break;
            case MiErrorCode.MI_XIAOMI_PAYMENT_ERROR_PAY_FAILURE:
                if(iapBaseListener!=null){
                    iapBaseListener.onBuyDidFail();
                }
                break;
            case MiErrorCode.MI_XIAOMI_PAYMENT_ERROR_PAY_REPEAT:
                if(iapBaseListener!=null) {
                    iapBaseListener.onBuyDidBuy();
                }
                break;
            case MiErrorCode.MI_XIAOMI_PAYMENT_ERROR_ACTION_EXECUTED:

                break;
            case MiErrorCode.MI_XIAOMI_PAYMENT_ERROR_LOGIN_FAIL:

                break;
            default:
                break;
        }
    }
}

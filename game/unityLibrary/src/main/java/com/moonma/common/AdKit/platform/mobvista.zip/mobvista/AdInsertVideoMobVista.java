package com.moonma.common;

import android.app.Activity;

import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.net.ConnectivityManager;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.RelativeLayout;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.Toast;
import java.util.HashMap;


import com.mintegral.msdk.interstitialvideo.out.MTGInterstitialVideoHandler;
import com.mintegral.msdk.videocommon.download.NetStateOnReceive;
import com.moonma.common.IAdInsertBase;
import com.moonma.common.IAdInsertBaseListener; 
import com.moonma.common.AdConfigMobVista;



import com.mintegral.msdk.MIntegralConstans;
import com.mintegral.msdk.interstitialvideo.out.InterstitialVideoListener;
import com.mintegral.msdk.interstitialvideo.out.MTGInterstitialVideoHandler;
import com.mintegral.msdk.videocommon.download.NetStateOnReceive;
 
public class AdInsertVideoMobVista implements IAdInsertBase {

    // 自定义单一平台广告视图对象
    // private AdView adView;

    private static String TAG = "AdInsertVideo";

    public boolean isUseActivity = false;// true
    boolean isAdInit;
    FrameLayout framelayout;
    Activity mainActivity;
    private boolean sIsShow;
    private int bannerOffsety;
    private float bannerAlhpha;
    String strAdAppId;

    private MTGInterstitialVideoHandler mMtgInterstitalVideoHandler;

    private IAdInsertBaseListener adInsertBaseListener;

    public void init(Activity activity, FrameLayout layout) {
        mainActivity = activity;
        framelayout = layout;
        isAdInit = false;
    }

    public void setAd() {
        if(isAdInit==false)
        {
            isAdInit = true;
            initHandler();
        }
    }

    public void show() {

        mainActivity.runOnUiThread( new Runnable()
        {
            @Override
            public void run()
            {
                mMtgInterstitalVideoHandler.load();

            }
        } );
    } 
 

    public void setListener(IAdInsertBaseListener listener) {
        adInsertBaseListener = listener;
    }


    private void initHandler() {
        try {
            // Declare network status for downloading video
//            if (mNetStateOnReceive == null) {
//                mNetStateOnReceive = new NetStateOnReceive();
//                IntentFilter filter = new IntentFilter();
//                filter.addAction(ConnectivityManager.CONNECTIVITY_ACTION);
//                registerReceiver(mNetStateOnReceive, filter);
//            }
            String strAppKey = AdConfigMobVista.main().appKeyInsertVideo;
            Log.e(TAG, "strAppKey:"+strAppKey);
            mMtgInterstitalVideoHandler = new MTGInterstitialVideoHandler(mainActivity, strAppKey);
            mMtgInterstitalVideoHandler.setInterstitialVideoListener(new InterstitialVideoListener() {

                @Override
                public void onLoadSuccess(String unitId) {
                    Log.e(TAG, "onLoadSuccess:"+Thread.currentThread());


                }

                @Override
                public void onVideoLoadSuccess(String unitId) {
                    Log.e(TAG, "onVideoLoadSuccess:"+Thread.currentThread());

                    if (mMtgInterstitalVideoHandler != null) {
                        mMtgInterstitalVideoHandler.show();
                    }
                }

                @Override
                public void onVideoLoadFail(String errorMsg) {
                    Log.e(TAG, "onVideoLoadFail errorMsg:"+errorMsg);
                    if (adInsertBaseListener!=null){
                        adInsertBaseListener.adInsertDidFail();

                    }
                }

                @Override
                public void onShowFail(String errorMsg) {
                    Log.e(TAG, "onShowFail=" + errorMsg);
                  //  Toast.makeText(getApplicationContext(), "errorMsg:" + errorMsg, Toast.LENGTH_SHORT).show();
                }

                @Override
                public void onAdShow() {
                    Log.e(TAG, "onAdShow");
                    if (adInsertBaseListener!=null){
                        adInsertBaseListener.adInsertWillShow();

                    }
                }

                @Override
                public void onAdClose(boolean isCompleteView) {
                    Log.e(TAG, "onAdClose rewardinfo :" +  "isCompleteView："+isCompleteView);

                    if (adInsertBaseListener!=null){
                        adInsertBaseListener.adInsertDidClose();
                    }
                }

                @Override
                public void onVideoAdClicked(String unitId) {
                    Log.e(TAG, "onVideoAdClicked");

                }

            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

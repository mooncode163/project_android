package com.moonma.common;

import android.app.Activity;

import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.FrameLayout;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.moonma.common.IAdBannerBase;
import com.moonma.common.IAdBannerBaseListener;
import com.moonma.common.AdConfigChsj;


import org.json.JSONObject;

import java.util.Locale;


import com.bytedance.sdk.openadsdk.AdSlot;
import com.bytedance.sdk.openadsdk.FilterWord;
import com.bytedance.sdk.openadsdk.TTAdConstant;
import com.bytedance.sdk.openadsdk.TTAdDislike;
import com.bytedance.sdk.openadsdk.TTAdNative;
import com.bytedance.sdk.openadsdk.TTAppDownloadListener;
import com.bytedance.sdk.openadsdk.TTNativeExpressAd;


public class AdBannerChsj implements IAdBannerBase {

    // 自定义单一平台广告视图对象
    // private AdView adView;
    private static String TAG = "AdBanner";

    FrameLayout framelayout;
    Activity mainActivity;
    private boolean sIsShow;
    private int bannerOffsety;
    static int heightAd;
    int widthAd;
    int heigtAdMin = 8;
    float heightRatioMin = 0.15f;
    private float bannerAlhpha;

    // AdView adView;
    FrameLayout framelayoutAd;
    IAdBannerBaseListener adBannerBaseListener;
    boolean isAdInit;

    public void init(Activity activity, FrameLayout layout) {
        mainActivity = activity;
        framelayout = layout;
        isAdInit = false;
        sIsShow = false;

    }

    public void setAd() {
        if (isAdInit == false) {
            isAdInit = true;

            String strAppId = AdConfigChsj.main().appId;
            String strAppKey = AdConfigChsj.main().appKeyBanner;

            Log.i(TAG, "banner id=" + strAppId + " key=" + strAppKey);


            //设置广告参数
            AdSlot adSlot = new AdSlot.Builder()
                    .setCodeId(strAppKey) //广告位id
                    .setSupportDeepLink(true)
                    .setAdCount(1) //请求广告数量为1到3条
                    .setExpressViewAcceptedSize(expressViewWidth,expressViewHeight) //期望个性化模板广告view的size,单位dp
                    .setImageAcceptedSize(640,320 )//这个参数设置即可，不影响个性化模板广告的size
                    .build();
//            //加载广告
//            mTTAdNative.loadBannerExpressAd(adSlot, new TTAdNative.NativeExpressAdListener() {
//                @Override
//                public void onError(int code, String message) {
//                    TToast.show(NativeExpressActivity.this, "load error : " + code + ", " + message);
//                    mExpressContainer.removeAllViews();
//                }
//
//                @Override
//                public void onNativeExpressAdLoad(List<TTNativeExpressAd> ads) {
//                    if (ads == null || ads.size() == 0){
//                        return;
//                    }
//                    mTTAd = ads.get(0);
//                    mTTAd.setSlideIntervalTime(30*1000);//设置轮播间隔 ms,不调用则不进行轮播展示
//                    bindAdListener(mTTAd);
//                    mTTAd.render();//调用render开始渲染广告
//                }
//            });
//            //绑定广告行为
//            private void bindAdListener(TTNativeExpressAd ad) {
//                ad.setExpressInteractionListener(new TTNativeExpressAd.ExpressAdInteractionListener() {
//                    @Override
//                    public void onAdClicked(View view, int type) {
//                        TToast.show(mContext, "广告被点击");
//                    }
//
//                    @Override
//                    public void onAdShow(View view, int type) {
//                        TToast.show(mContext, "广告展示");
//                    }
//
//                    @Override
//                    public void onRenderFail(View view, String msg, int code) {
//                        Log.e("ExpressView","render fail:"+(System.currentTimeMillis() - startTime));
//                        TToast.show(mContext, msg+" code:"+code);
//                    }
//
//                    @Override
//                    public void onRenderSuccess(View view, float width, float height) {
//                        //返回view的宽高 单位 dp
//                        TToast.show(mContext, "渲染成功");
//                        //在渲染成功回调时展示广告，提升体验
//                        mExpressContainer.removeAllViews();
//                        mExpressContainer.addView(view);
//                    }
//                });
//                //dislike设置
//                bindDislike(ad, false);
//                if (ad.getInteractionType() != TTAdConstant.INTERACTION_TYPE_DOWNLOAD){
//                    return;
//                }
//                //可选，下载监听设置
//                ad.setDownloadListener(new TTAppDownloadListener() {
//                    @Override
//                    public void onIdle() {
//                        TToast.show(BannerExpressActivity.this, "点击开始下载", Toast.LENGTH_LONG);
//                    }
//
//                    @Override
//                    public void onDownloadActive(long totalBytes, long currBytes, String fileName, String appName) {
//                        if (!mHasShowDownloadActive) {
//                            mHasShowDownloadActive = true;
//                            TToast.show(BannerExpressActivity.this, "下载中，点击暂停", Toast.LENGTH_LONG);
//                        }
//                    }
//
//                    @Override
//                    public void onDownloadPaused(long totalBytes, long currBytes, String fileName, String appName) {
//                        TToast.show(BannerExpressActivity.this, "下载暂停，点击继续", Toast.LENGTH_LONG);
//                    }
//
//                    @Override
//                    public void onDownloadFailed(long totalBytes, long currBytes, String fileName, String appName) {
//                        TToast.show(BannerExpressActivity.this, "下载失败，点击重新下载", Toast.LENGTH_LONG);
//                    }
//
//                    @Override
//                    public void onInstalled(String fileName, String appName) {
//                        TToast.show(BannerExpressActivity.this, "安装完成，点击图片打开", Toast.LENGTH_LONG);
//                    }
//
//                    @Override
//                    public void onDownloadFinished(long totalBytes, String fileName, String appName) {
//                        TToast.show(BannerExpressActivity.this, "点击安装", Toast.LENGTH_LONG);
//                    }
//                });
//            }
//            /**
//             * 设置广告的不喜欢，开发者可自定义样式
//             * @param ad
//             * @param customStyle 是否自定义样式，true:样式自定义
//             */
//            private void bindDislike(TTNativeExpressAd ad, boolean customStyle) {
//                if (customStyle) {
//                    //使用自定义样式
//                    List<FilterWord> words = ad.getFilterWords();
//                    if (words == null || words.isEmpty()) {
//                        return;
//                    }
//
//                    final DislikeDialog dislikeDialog = new DislikeDialog(this, words);
//                    dislikeDialog.setOnDislikeItemClick(new DislikeDialog.OnDislikeItemClick() {
//                        @Override
//                        public void onItemClick(FilterWord filterWord) {
//                            //屏蔽广告
//                            TToast.show(mContext, "点击 " + filterWord.getName());
//                            //用户选择不喜欢原因后，移除广告展示
//                            mExpressContainer.removeAllViews();
//                        }
//                    });
//                    ad.setDislikeDialog(dislikeDialog);
//                    return;
//                }
//                //使用默认个性化模板中默认dislike弹出样式
//                ad.setDislikeCallback(BannerExpressActivity.this, new TTAdDislike.DislikeInteractionCallback() {
//                    @Override
//                    public void onSelected(int position, String value) {
//                        TToast.show(mContext, "点击 " + value);
//                        //用户选择不喜欢原因后，移除广告展示
//                        mExpressContainer.removeAllViews();
//                    }
//
//                    @Override
//                    public void onCancel() {
//                        TToast.show(mContext, "点击取消 ");
//                    }
//                });
//            }
//
//            //在合适的时机，释放广告的资源
//            @Override
//            protected void onDestroy() {
//                super.onDestroy();
//                if (mTTAd != null) {
//                    //调用destroy()方法释放
//                    mTTAd.destroy();
//                }
//            }



//            loadBannerExpressAd(  adSlot, @NonNull NativeExpressAdListener listener)
        }

    }

    public void setAlpha(float alpha) {

        bannerAlhpha = alpha;
        if (mainActivity == null) {
            return;
        }
        mainActivity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (bannerAlhpha < 1.0) {
                    // bannerAlhpha =0;
                }
                framelayoutAd.setAlpha(bannerAlhpha);

            }
        });

    }

    private void doCloseBanner() {
        framelayoutAd.removeAllViews();
        if (bv != null) {
            bv.destroy();
            bv = null;
        }
    }

    public void show(boolean isShow) {
        sIsShow = isShow;

        if (mainActivity == null) {
            return;
        }

        mainActivity.runOnUiThread(new Runnable() {
            @Override
            public void run() {

                if (bv == null) {
                    return;
                }
                if (sIsShow) {

                    // bv.loadAD();
                    bv.setVisibility(View.VISIBLE);
                    framelayoutAd.setVisibility(View.VISIBLE);

                } else {
                    bv.setVisibility(View.INVISIBLE);
                    framelayoutAd.setVisibility(View.INVISIBLE);
                    // framelayoutAd.removeAllViews();
                    // doCloseBanner();
                }
            }
        });

    }

    public void layoutSubView(int w, int h) {
        // setOffsetY(bannerOffsety);

    }

    public void setOffsetYInternal() {
        mainActivity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                int screen_w = framelayout.getWidth();
                int screen_h = framelayout.getHeight();
                int h_adbanner = heightAd;
                if (h_adbanner < heigtAdMin) {// 0 ,1,126
                    // 显示到屏幕外
                    return;
                }
                // h = 128;
                float ratio_h = h_adbanner * 1.0f / screen_h;
                float scale = 1f;
                if ((ratio_h > heightRatioMin) && (screen_w > screen_h)) {
                    // 横屏 显示面积过大 缩小一些
                    ratio_h = heightRatioMin;
                    // h_adbanner = (int)(ratio_h*screen_h);
                    scale = h_adbanner * 1.0f / heightAd;
                    // framelayoutAd.setScaleX(scale);
                    // framelayoutAd.setScaleY(scale);
                }
                Log.i(TAG, "setOffsetYInternal h_adbanner=" + h_adbanner + " scale=" + scale + " heightAd=" + heightAd);
                int x = (screen_w - widthAd) / 2;
                int oft_bottom = com.moonma.common.ScreenUtil.getBottomNavigationBarHeight();
                if (Device.isLandscape()) {
                    // 华为全面屏 底部导航栏 横屏时候现在在右边
                    oft_bottom = 0;
                }
                int y = screen_h - h_adbanner - bannerOffsety
                        - oft_bottom;

                // y = 128;
                // framelayoutAd.setX(x);
                framelayoutAd.setY(y);

                bv.setY(0);
                // bv.bringToFront();
                // framelayoutAd.bringToFront();

                if (adBannerBaseListener != null) {
                    adBannerBaseListener.onReceiveAd(widthAd, h_adbanner);
                }
            }
        });

    }

    public void setOffsetY(int y) {

        bannerOffsety = y;
        //
        //
        if ((bv == null) || (framelayout == null) || (mainActivity == null)) {
            return;
        }
        mainActivity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (bv == null) {
                    return;
                }
                if (framelayoutAd.getVisibility() != View.VISIBLE) {
                    return;
                }
                widthAd = bv.getWidth();
                // heightAd = bv.getHeight();

                if (heightAd <= heigtAdMin) {
                    // 显示到屏幕外 解决banner可能不显示的问题
                    heightAd = 126;
                }
                setOffsetYInternal();

            }

        });

        ViewTreeObserver vto2 = bv.getViewTreeObserver();
        vto2.addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
            @Override
            public void onGlobalLayout() {
                // bv.getViewTreeObserver().removeGlobalOnLayoutListener(this);
                widthAd = bv.getWidth();
                int htmp = bv.getHeight();
                if (htmp > heigtAdMin) {
                    // 显示到屏幕外 解决banner可能不显示的问题
                    int heightAdPre = heightAd;
                    heightAd = htmp;

                    bv.getViewTreeObserver().removeGlobalOnLayoutListener(this);

                    // 定时更新
                    // Handler hd = new Handler();
                    // Runnable r = new Runnable() {
                    // @Override
                    // public void run() {
                    // setOffsetYInternal();
                    // }
                    // };
                    //
                    // hd.postDelayed(r, 3000);//ms
                    // setOffsetYInternal();
                    // 重新加载
                    if (heightAdPre != heightAd) {
                        bv.loadAD();
                    }
                }
            }
        });

    }

    public void setListener(IAdBannerBaseListener listener) {
        adBannerBaseListener = listener;

    }

    public interface OnAdBannerListener {

        void onReceiveAd(int w, int h);
    }

    @Override
    public void onNoAD(AdError adError) {
        String msg = String.format(Locale.getDefault(), "onNoAD, error code: %d, error msg: %s", adError.getErrorCode(),
                adError.getErrorMsg());
        Log.i(TAG, msg);
        // Toast.makeText(this, msg, Toast.LENGTH_LONG).show();
        if (adBannerBaseListener != null) {
            adBannerBaseListener.onLoadAdFail();
        }
    }

    @Override
    public void onADReceive() {
        Log.i(TAG, "onADReceive");
        setOffsetY(bannerOffsety);
    }

    @Override
    public void onADExposure() {
        Log.i(TAG, "onADExposure");
        // setOffsetYInternal();
    }

    @Override
    public void onADClosed() {
        Log.i(TAG, "onADClosed");
    }

    @Override
    public void onADClicked() {
        Log.i(TAG, "onADClicked");
    }

    @Override
    public void onADLeftApplication() {
        Log.i(TAG, "onADLeftApplication");
    }

    @Override
    public void onADOpenOverlay() {
        Log.i(TAG, "onADOpenOverlay");
    }

    @Override
    public void onADCloseOverlay() {
        Log.i(TAG, "onADCloseOverlay");
    }
}

package com.moonma.common;

import android.app.Activity;

import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.RelativeLayout;
import android.widget.Toast;

import org.json.JSONObject;

import com.moonma.common.IAdInsertBase;
import com.moonma.common.IAdInsertBaseListener;
import com.moonma.common.AdConfigVungle;

import com.vungle.warren.AdConfig;
import com.vungle.warren.InitCallback;
import com.vungle.warren.LoadAdCallback;
import com.vungle.warren.PlayAdCallback;
import com.vungle.warren.Vungle;
import com.vungle.warren.VungleNativeAd;
import com.vungle.warren.Vungle.Consent;
import com.vungle.warren.error.VungleException;

public class AdInsertVungle implements IAdInsertBase  {

    private   String TAG = this.getClass().getSimpleName();

    private static int ordinal = 1;

   static boolean isAdInit;
    Activity mainActivity;
    private   boolean sIsShow;
    private   int bannerOffsety;
    private   float bannerAlhpha;
    int adType;

   boolean isAutoShow;
    boolean isLoading;
    private IAdInsertBaseListener adInsertBaseListener;

    public   void init(  Activity activity,FrameLayout layout)
    {
        mainActivity = activity;
        //framelayout = layout;
        isAdInit = false;
    }

    public void setType(int type)
    {
        adType = type;
    }
     public void setAd()
    {

        if(isAdInit==false)
        {
            isAdInit = true;
            String strAppId = AdConfigVungle.main().appId;
            loadAd(false);
        }

    }

    public void show() {

        mainActivity.runOnUiThread( new Runnable()
        {
            @Override
            public void run()
            {
                String strAppKey = AdConfigVungle.main().appKeyInsert;
                if (Vungle.isInitialized() && Vungle.canPlayAd(strAppKey)) {
                    showAd();
                }else {
                    loadAd(true);
                }
            }
        } );

    }

     public void setListener(IAdInsertBaseListener listener) {
        adInsertBaseListener = listener;
    }


    public void loadAd(boolean autoshow) {
        isAutoShow = autoshow;
        if(isLoading){
            Log.d(TAG,"ad is loading,waiting...");
            return;
        }
        isLoading = true;
        String strAppKey = AdConfigVungle.main().appKeyInsert;
        if (Vungle.isInitialized() )
        {
            Vungle.loadAd(strAppKey, vungleLoadAdCallback);
        }
    }
    public void showAd() {
        String strAppKey = AdConfigVungle.main().appKeyInsert;
        if (Vungle.isInitialized() && Vungle.canPlayAd(strAppKey)) {
            // Play Dynamic Template ad
            Vungle.playAd(strAppKey, null, vunglePlayAdCallback);
        }
    }
    private final PlayAdCallback vunglePlayAdCallback = new PlayAdCallback() {
        @Override
        public void onAdStart(final String placementReferenceID) {
            Log.d(TAG, "PlayAdCallback - onAdStart" +
                    "\n\tPlacement Reference ID = " + placementReferenceID);

               if (adInsertBaseListener!=null){
                    adInsertBaseListener.adInsertWillShow();

                }
        }

        @Override
        public void onAdEnd(final String placementReferenceID, final boolean completed, final boolean isCTAClicked) {
            Log.d(TAG, "PlayAdCallback - onAdEnd" +
                    "\n\tPlacement Reference ID = " + placementReferenceID +
                    "\n\tView Completed = " + completed + "" +
                    "\n\tDownload Clicked = " + isCTAClicked);


        }

        @Override
        public void onError(final String placementReferenceID, Throwable throwable) {
            Log.d(TAG, "PlayAdCallback - onError" +
                    "\n\tPlacement Reference ID = " + placementReferenceID +
                    "\n\tError = " + throwable.getLocalizedMessage());
//

//            if(adVideoBaseListener!=null){
//                adVideoBaseListener.adVideoDidFail();
//            }
        }
    };

    private final LoadAdCallback vungleLoadAdCallback = new LoadAdCallback() {
        @Override
        public void onAdLoad(final String placementReferenceID) {

            Log.d(TAG,"LoadAdCallback - onAdLoad" +
                    "\n\tPlacement Reference ID = " + placementReferenceID);
//

            isLoading = false;
            if(isAutoShow){
                showAd();
            }

        }

        @Override
        public void onError(final String placementReferenceID, Throwable throwable) {
            Log.d(TAG, "LoadAdCallback - onError" +
                    "\n\tPlacement Reference ID = " + placementReferenceID +
                    "\n\tError = " + throwable.getLocalizedMessage());

            isLoading = false;
              if (adInsertBaseListener!=null){
                    adInsertBaseListener.adInsertDidFail();

                }
        }
    };


}

package com.moonma.common;

import android.app.Activity;

import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.RelativeLayout;

import com.moonma.common.IAdInsertBase;
import com.moonma.common.IAdInsertBaseListener;
import com.moonma.common.AdConfigAdView;

//adview 
import com.kyview.interfaces.AdViewInstlListener;
import com.kyview.manager.AdViewInstlManager;

public class AdInsertAdView implements IAdInsertBase,AdViewInstlListener {

    // 自定义单一平台广告视图对象
    // private AdView adView;

    private static String TAG = "AdInsert";

    public boolean isUseActivity = false;// true
    boolean isAdInit;
    FrameLayout framelayout;
    Activity mainActivity;
    private boolean sIsShow;
    private int bannerOffsety;
    private float bannerAlhpha;
    String strAdAppId;
    // InterstitialAd interAd;

    private IAdInsertBaseListener adInsertBaseListener;

    public void init(Activity activity, FrameLayout layout) {
        mainActivity = activity;
        framelayout = layout;
        isAdInit = false;
    }

    public void setAd() {

        if (isAdInit == false) {
            isAdInit = true;

            String strAppId = AdConfigAdView.main().appId;
            String strAppKey = AdConfigAdView.main().appKeyInsert;
            strAdAppId = strAppId;

            Log.i(TAG, "insert id=" + strAppId + " key=" + strAppKey);

        }

    }

    public void show() {

        mainActivity.runOnUiThread(new Runnable() {
            @Override
            public void run() {

                loadAd(strAdAppId);
            }
        });
    }
    void loadAd(String appid) {
        if(appid==null) {
            return;
        }
        // 只请求广告，适用于预加载
        AdViewInstlManager.getInstance(mainActivity).requestAd(mainActivity, appid, this);

    }


     void showAdInsert() {
         if(strAdAppId==null) {
             return;
         }
        mainActivity.runOnUiThread(new Runnable() {
            @Override
            public void run() {

                // iad.loadAD();
                AdViewInstlManager.getInstance(mainActivity).showAd(mainActivity, strAdAppId);
            }
        });
    }

    public void setListener(IAdInsertBaseListener listener) {
        adInsertBaseListener = listener;
    }

    public void startSplashAd(final String strAppId, final String strAppKey) {

    }

    @Override
    public void onAdClick(String arg0) {
        Log.i("AdInstlActivity", "onAdClick");
    }

    @Override
    public void onAdDismiss(String arg0) {
        Log.i(TAG, "onAdDismiss");
        if (adInsertBaseListener != null) {
            adInsertBaseListener.adInsertDidClose();

        }
    }

    @Override
    public void onAdDisplay(String arg0) {
        Log.i(TAG, "onDisplayAd");
        if (adInsertBaseListener != null) {
            adInsertBaseListener.adInsertWillShow();

        }
    }

    @Override
    public void onAdFailed(String arg0) {
        Log.i(TAG, "onAdFailed");
        // Toast.makeText(AdInstlActivity.this, "onReceiveAdFailed",
        // Toast.LENGTH_SHORT).show();
        if (adInsertBaseListener != null) {
            adInsertBaseListener.adInsertDidFail();

        }
    }

    @Override
    public void onAdRecieved(String arg0) {
        Log.i(TAG, "onReceivedAd");
        // Toast.makeText(AdInstlActivity.this, "onAdRecieved",
        // Toast.LENGTH_SHORT).show();
        showAdInsert();
    }

    public interface OnAdInsertListener {

        void adInsertWillShow();

        void adInsertDidClose();
    }
}
